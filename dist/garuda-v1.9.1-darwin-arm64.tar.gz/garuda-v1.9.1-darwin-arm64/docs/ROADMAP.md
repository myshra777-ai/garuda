

```markdown
# Garuda — Roadmap

**Forward-looking. What ships, in what order, behind what gates.**

Status: authoritative internal roadmap. Local-only, gitignored.
Companion: [`docs/TRACKING.md`](TRACKING.md) — the backward-looking log.
Multi-tenant detail: [`docs/multi-tenant-roadmap.md`](multi-tenant-roadmap.md).

Last updated: 2026-09-16.

---

## How to read this document

Every phase, item, and gate in this document carries one of six labels:

| Label | Meaning |
| :--- | :--- |
| **Stable** | Verified with tests. In use. A regression would be caught by CI. |
| **Beta** | Implemented and tested. Not hardened. Not yet validated against a real user. |
| **Alpha** | Implemented, partial coverage, no versioned spec. |
| **In-flight** | Currently being worked on. |
| **Not started** | Queued. No code. |
| **Deferred** | Intentionally frozen. Will not be worked on before its stated prerequisite closes. |

A phase is never advanced to the next label without an exit criterion
being met. The exit criterion is a test or a measurement, not a feeling.

---

## Current maturity

Completion percentages express implementation against the roadmap, not
accuracy. A 75% built analyzer may still be untrustworthy if relationship
precision is unknown.

| Area | Completion | Truthful state and gap |
| :--- | ---: | :--- |
| Architecture and product thesis | 85% | Strong, coherent foundation. |
| Go semantic extraction | 75% | Implemented. Golden coverage must expand. |
| Entity identity | 70% | Deterministic. Lifecycle behaviour needs proof. |
| Relationship resolution | 55% | **Highest false-positive risk.** |
| Evidence / provenance | 65% | Model implemented. Invariant and replay proof required. |
| Revisions / integrity | 80% | Strong foundation. Adversarial verification required. |
| Semantic diff | 70% | Implemented. Golden semantic-diff corpus required. |
| Impact analysis | 65% | Implemented. Authoritative TP/FP/FN measurement required. |
| CLI / dashboard / graph | 80% | Feature-rich. Freeze expansion. |
| Runtime verification | 55% | Beta. Coverage semantics required. |
| MCP / IDE / AI workflows | 60% | Beta. Authorization and faithfulness proof required. |
| CI / judge workflows | 65% | Beta. Noise and acceptance metrics needed. |
| Multi-repo intelligence | 55% | Alpha. 10-to-25 repo truth set missing. |
| Benchmark authority | 35% | **Controlled evidence exists. Versioned goldens missing.** |
| Security / isolation hardening | 55% | Architecture strong. Adversarial suite incomplete. |
| Production operations | 50% | Durable-job and scale evidence needed. |
| Company Brain | 35% | Software truth foundation only. |
| Trusted state / governance | 25% | Long-term expansion. No premature product claim. |

**Interpretation.** Garuda's most advanced areas are architecture, product
thesis, the semantic model direction, revisions and integrity, and the
developer surfaces. The largest gap is not lack of features. It is
**authoritative proof of semantic correctness** — especially relationships,
impact analysis, provenance, and cross-repository resolution.

---

## Phases

| Phase | Focus | Status | Exit criterion |
| :--- | :--- | :--- | :--- |
| **P0** | Trust cleanup | **Closed** | All original items closed. See `docs/TRACKING.md`. |
| **P1** | Semantic core | **Beta** | Versioned semantic spec plus a migration policy. |
| **P2** | Analyzer | **Beta** | Type-aware deterministic extraction with source evidence. Go at Tier 5. Python and TypeScript at Tier 2. |
| **P3** | Artifacts and CLI | **Beta** | End-to-end with structured output and source-evidence drilldown. |
| **P4** | Benchmark authority | **Alpha** | Synthetic corpus, goldens, metrics, and regression gates enforced in CI. |
| **P5** | Multi-repo | **Alpha** | 10-to-25 repo graph with permission-aware resolution. Cross-language resolution is heuristic today. |
| **P6** | Company Brain | **Deferred** | Overview, architecture graph, evidence explorer, meeting mode. Product identity, not yet delivered. |
| **P7** | CI impact and runtime | **Beta** | Measured impact precision and recall. Runtime correlation exercised on real traces and on contradictions. |
| **P8** | Governance | **Beta** | Authority-backed decisions. Conflict review workflow. |
| **P9** | Business integrity | **Deferred** | Domain-specific state-invariant pilot with real users. |
| **P10** | Ponytail (code minimalism) | **Alpha** | Report-only findings with baselines. |
| **P11** | MCP surface | **Beta** | Tool surface complete for beta. Runtime coverage and blast-radius tools queued. |

---

## Trust-floor queue

The trust floor is the set of items that must be closed before anyone
outside the project runs Garuda. If the floor is wrong, the first
tester finds the crack, and the project loses the bet.

### Closed

The full closed list lives in [`docs/TRACKING.md`](TRACKING.md). Every
item below is committed and verified.

| ID | Item | Verification |
| :-: | :--- | :--- |
| **T1** | Merkle trust layer verified end-to-end | All vector tests pass. `garuda policy verify <id>` returns VALID on live anchors. `VerifyInclusion` and `VerifyV1Proof` are pure — no store, no DB, no network. |
| **T19** | ADR fixture exercising the CALLS verification path | Ingest produced four claims; the verifier flipped two to SUPPORTED, left one UNVERIFIED with an honest reason, and rejected one non-entity bullet. |
| **T23** | Handler ON CONFLICT targets matched to real constraints | `scripts/runtime_contradiction_test.py` produces 10/10 contradicted on three consecutive runs. |
| **T31** | Bench resolves workspace within the active tenant | Pre-fix: cross-tenant leak (`default` in tenant `e2f82aa6`). Post-fix: resolves to `go-validation-10` in the canonical tenant. Commit `995797e`. |
| **T32** | `ResolveWorkspaceTarget` scoped by tenant | Both named lookup and fallback now filter by `tenant_id` with deterministic `ORDER BY`. Commit `2008251`. |
| **T33** | I-11 Class A audit, first wave | Three bugs in `InspectEntityDetails` (entity lookup + both claims queries). Commit `2e5ea3c`. Verified by two-workspace CLI runs. |
| **T34** | CODE→DOC drift query scoped by workspace | Commit `a8f8adf`. Pre-fix returned entities from the wrong workspace; post-fix returns only the requested workspace. |
| **T35** | Checkpoint path verified end-to-end | Checkpoint creation, handoff transaction, and resume path exercised. |
| **T36** | Merkle read-path scoping fix | Read-path queries now filter by workspace where they previously did not. |
| **T37** | I-11 audit — full closure | All 200 queries classified. 18 bugs found and fixed. See I-11 audit section below. |
| **T38** | Audit-store deletion | Dead store removed. Commit `b5ab860`. |
| **T39** | Policy verify path scoped | Policy verification now filters by workspace. Commit `ff35dab`. |
| **T40** | Policy show uses `loadEvaluation` | Commit `27de1ea`. |
| **T41** | `upsertPolicy` UPDATE scoped | Commit `598dcc0`. |
| **T42** | Two-agent handoff Go test | Commit `c2e3164`. |

### In flight

None.

### Queued

| # | Item | Severity | Note |
| :-: | :--- | :--- | :--- |
| **B15** | `audit_events` scoping | Medium | Query filtering gap identified during the I-11 audit expansion. |
| **B16** | `supersede` not transactional | Medium | `supersede` writes are not wrapped in a transaction. Partial writes are possible. |
| **B17** | `hashPolicyYAML` is a stub | Medium | Returns a placeholder. Policy revision hashing is not real. |
| **B18** | `ListByScope` has no callers | Low | Dead code. Delete or repurpose. |
| 1 | `resolveWorkspaceID` ordering — `LIMIT 1` with no `ORDER BY` | Low | Rides with any commit touching `dashboard_handlers.go`. |
| 2 | SUPPORTED claims do not revert when their observation is deleted | Medium | Policy decision needed. See D1 below. |
| 3 | JSONB shape metadata for non-normative document content | Deferred | Middle ground between fixed and dynamic schema. Requires a Merkle version bump. |
| 4 | `docs/CAPABILITIES.md` stale | Medium | Auto-generated snapshot from 2026-09-14. Public-facing. |
| 6 | `handleGraph` accepts a workspace-name argument and does not use it | Low | `resolveWorkspace(ctx)` reads `GARUDA_WORKSPACE` regardless. |
| 7 | Workspace table contains duplicate names | Medium | Test residue, not a bug (verified: 44 workspaces, 43 distinct tenants). |
| 8 | Migration filenames contain duplicates | Medium | `001`, `002`, `003`, `005`, `007`, `013`, `014`/`016` each appear twice. Runs differ by sort order. |
| 9 | 10 entities reference a `workspace_id` with no matching `workspaces` row | Low | Orphaned references; needs a cleanup migration. |
| 10 | `GetClaimsByWorkspace` has no callers | Low | Documented in its own comment. Delete or keep as reference. |
| 11 | `bench_cmd.go` opens its own pool from `os.Getenv("DATABASE_URL")` | Low | Inconsistent with the rest of the CLI; the values coincide today. |
| 12 | Correlator name-based resolution ambiguous for duplicated names | Medium | `go-validation-10` contains 72 `test_tutorial`, 85 `create_db_and_tables`, 3 `test`. Every doc claim whose subject is duplicated resolves to one of N. |
| 13 | `coverage_percent` reason string says "unavailable" when inputs are observed-zero | Low | Message bug, not correctness. |

### Sequencing rule (locked)

Beta does not start on a floor whose numbers are only correct when
nobody looks. The trust-floor queue must be closed, or the item must be
explicitly accepted with a recorded rationale, before Session F
(onboarding).

**As of 2026-09-16, the I-11 audit is closed.** 200 of 200 queries
classified. 18 bugs found and fixed. The remaining pre-beta concerns
are the MCP surface expansion and the briefing tool, both of which
are tracked in the active work queue.

---

## Verification tiers

Garuda's claim strength depends on how a relationship was derived. The
tier travels with every claim.

| Tier | Method | Languages | Guarantee |
| :-: | :--- | :--- | :--- |
| **5** | Compiler type information | Go | Call edges, interface satisfaction, method sets, and embeds are compiler-resolved. Highest confidence. |
| **4** | Native type checker | (planned) Rust, Java | Not yet implemented. |
| **3** | Full AST with import resolution | (planned) Python, TypeScript | Not yet implemented. |
| **2** | Structural AST with import resolution | Python, TypeScript | Imports are reliable. Calls are heuristic. |
| **1** | Pattern matching | (not used) | Would be a lie. Not shipped. |

A claim carries its tier so the reader knows how strong the evidence is.
Tier 5 is the strongest claim Garuda makes. Tier 2 is a weaker claim and
is labelled as such in the dashboard, in the evidence document, and in
any export.

---

## Benchmark gates

A phase does not advance without a measurement. The gates below are
the measurements that advance a phase.

| Gate | What it measures | Advances |
| :--- | :--- | :--- |
| G1 | Versioned semantic spec exists and passes on all fixtures | P1 |
| G2 | Type-aware extraction with source evidence on real repos | P2 |
| G3 | Structured output and evidence drilldown on all commands | P3 |
| G4 | 20-fixture corpus with goldens and regression gates in CI | P4 |
| G5 | 10-to-25 repo graph with permission-aware resolution | P5 |
| G6 | 20-case Company Brain corpus delivered | P6 |
| G7 | Impact precision and recall measured on a named corpus | P7 |
| G8 | Authority-backed decisions with conflict review | P8 |
| G9 | One domain-specific state-invariant pilot with a real user | P9 |
| G10 | Ponytail findings published with baselines | P10 |
| G11 | Tool surface complete and verified against two clients | P11 |

---

## Multi-tenant sessions

The full detail lives in [`docs/multi-tenant-roadmap.md`](multi-tenant-roadmap.md).
What follows is the summary a reader needs to plan around.

### Sessions

| Session | Scope | Status |
| :--- | :--- | :--- |
| **A** | User identity and tenant membership | Closed |
| **B** | Workspace membership | Closed |
| **C** | Session model — `resolveWorkspaceForUser` replaces hardcoded tenant UUID | Closed |
| **D** | Admin telemetry | Closed |
| **E** | Dual dashboards | Closed |
| **F** | Onboard the beta testers | Pending. Gate, not code. |

### Isolation tests (must pass before Session F)

Five probes that verify tenant and workspace separation end to end:

1. Cross-tenant workspace name lookup returns 404, not the other tenant's data.
2. Cross-tenant dashboard stats request returns 404.
3. Cross-tenant MCP tool call returns 404.
4. Cross-workspace entity lookup within a single tenant returns only entities in the requested workspace.
5. Deleting a workspace does not orphan its entities, claims, relationships, or runtime observations.

### Rollback (per session)

Each session is a self-contained migration. Rolling back means
reverting the commit and the migration together. No session depends
on a partial state left by a prior session.

---

## I-11 audit — closed

The I-11 audit checks every SQL query in the codebase for workspace
and tenant scoping. The audit's final scope was **200 queries**: the
original 129 against eight workspace-scoped tables, plus 22 on
`workspaces` and 7 on `decision_revisions` — two tables the original
grep missed — plus 42 additional queries that surfaced during the
expanded sweep.

Scope rule: a query filtered by `workspace_id` alone is safe, because
`workspaces.id` is a UUID primary key unique across the deployment.
Same for `repository_id`. A query filtered by `tenant_id` alone,
reading from a workspace-scoped table, is a Class A bug.

### Final classification

| Batch | File | Queries | Bugs |
| :-: | :--- | :-: | :-: |
| 1 | `internal/store/semantic_store.go` | 21 | 0 |
| 2 | `internal/store/claim_store.go` | 5 | 0 |
| 3 | `internal/store/inspection_store.go` | 8 | **3 (fixed)** |
| 4 | `cmd/garuda-mcp/tools_graph.go` | 8 | 0 |
| 5 | `cmd/garuda-mcp/tools_semantic.go` + `tools_governance.go` | 5 | 0 |
| 6 | `internal/store/summary_store.go` | 14 | **2 (fixed)** |
| 7 | `workspaces` expansion | 22 | **3 (fixed)** |
| 8 | `decision_revisions` expansion | 7 | 0 |
| 9 | `internal/api/dashboard_handlers.go` | 14 | **4 (fixed)** |
| 10 | `internal/policy/evaluator.go` | 5 | **2 (fixed)** |
| 11 | `internal/runtime/correlator.go` + `internal/mcp/knowledge_tool.go` | 3 | **1 (fixed)** |
| 12 | `internal/store/merkle_store.go` + `impact_store.go` + `workspace.go` | 8 | **2 (fixed)** |
| 13 | `internal/selfdescribe/semantic.go` + `cmd/garuda/*` | 6 | **1 (fixed)** |
| 14 | `internal/runtime/verifier.go` | 5 | 0 |
| 15 | `internal/store/handoff_store.go` + `agent_store.go` | 69 | **3 (fixed)** |
| — | **Total** | **200** | **18 (all fixed)** |

### Arc conclusion

**The audit is closed.** 18 bugs found. All fixed. The pattern that
emerges is **nine instances of "two sources of truth"** — the same
underlying defect wearing different clothes:

1. Tenant resolution had two paths (`tenant_id` filter vs. name lookup).
2. Workspace resolution had two paths (explicit vs. fallback).
3. Entity lookup had two scopes (workspace-scoped vs. tenant-scoped).
4. Claims queries had two scopes (same defect, two queries).
5. Policy verify path had two scopes.
6. Policy show had two loaders (`loadEvaluation` vs. inline).
7. `upsertPolicy` UPDATE had two scopes.
8. Bench resolved workspace via two different resolutions.
9. Checkpoint path resolved agent via two different lookups.

The AST lint rule queued for Phase 2c exists to prevent the tenth.

The write path is clean. The pipeline does not leak across workspaces
on write. Every Class A and Class B bug found in the audit was
confined to the read and reporting layer, where they exposed metadata
visibility, not data corruption.

---

## Active work queue

The canonical list of what is being worked on right now.

| # | Item | Status | Depends on |
| :-: | :--- | :--- | :--- |
| 1 | I-11 audit | **Closed** — 200 of 200 classified, 18 bugs fixed | — |
| 2 | `garuda.briefing` MCP tool | Not started | D5, D6, D7 answered |
| 3 | AST lint rule (Phase 2c) | Not started | Design decision on which checks to implement |
| 4 | MCP surface expansion | Not started | Which HTTP routes become MCP tools |

**Closed this arc:**

| # | Item | Closed by |
| :-: | :--- | :--- |
| — | Reproducible CONTRADICTED-path script | `scripts/runtime_contradiction_test.py` |
| — | Reproducible extraction → verification loop | `scripts/doc_verify_test.py` |
| — | Roadmap and tracker consolidation | This file and `docs/TRACKING.md` |
| — | Checkpoint/resume verification script | Two-agent handoff Go test, commit `c2e3164` |

Rules unchanged:

1. One item fully verified before the next starts.
2. Read before write. Every item begins with the current state of the
   file, not from memory.
3. Every item ends with a run, a paste, a commit.
4. Backlog items ride with the next commit that touches the file.
5. No workarounds. A swallowed error is a bug, not a fallback.

---

## Open decisions

Items that need a decision from the project owner, not a code change.

### D1 — the 176 SUPPORTED rows that do not revert

The verifier's UNVERIFIED branch has:

```sql
ON CONFLICT (workspace_id, tenant_id, source_entity_id, target_entity_id)
DO UPDATE SET
  status = 'UNVERIFIED',
  reason = 'NO_RUNTIME_OBSERVATION',
  last_evaluated_at = NOW()
WHERE claim_verifications.status NOT IN ('SUPPORTED', 'CONTRADICTED');
```

The guard prevents flapping. It also leaves stale SUPPORTED rows after
the underlying observation is deleted. Two policies:

- **Policy A — revert on observation delete.** The claim falls back to
  UNVERIFIED when its only evidence is removed. Matches the model's
  semantics: SUPPORTED means "an observation exists."
- **Policy B — grace window.** The claim stays SUPPORTED for N
  minutes after the observation is deleted, on the theory that
  observation deletion is usually a transient cleanup.

The current behaviour is effectively "stay SUPPORTED forever." That is
neither A nor B and needs to be resolved.

### D2 — multi-tenant session ordering

Sessions A through F have stated prerequisites. The order may need to
change once Session A produces real traffic and reveals which of the
later sessions is the actual blocker.

### D3 — roadmap and tracker version control

Both files are gitignored. They are a single point of failure on one
laptop. Before beta, decide whether to:

- Commit them to a private branch.
- Back them up to a separate location.
- Accept the risk because the content is derivable from the code and
  the commit history.

### D4 — the Company Brain scope

P6 is deferred as product identity, not engineering work. Before
committing to it, decide what it actually means: a dashboard? an
API? a set of MCP tools? a narrative? The scope question is the
reason it is deferred.

### D5 — the briefing core: fixed or configurable

`garuda.briefing` needs a decision about what the fixed core contains.
The proposal is seven sections always returned (workspace, trust,
scale, hubs, policies, attention, new_since) plus agent-requested
extension sections. The alternative is a fully configurable briefing
with no fixed core. The fixed core is easier to reason about; the
configurable version is more flexible.

### D6 — the lessons design

Design A (lessons as first-class observations, derived, decayed,
readable, revocable) versus Design B (opaque ranking signal). Design A
fits the vision; Design B is smaller. The proposal endorses Design A.
The decision is whether to ship Design A now or ship Design B and
upgrade later.

### D7 — the checkpoint/briefing/lessons interaction

If `garuda.briefing` and `garuda.lessons` ship, does a checkpoint
carry the briefing state and the lesson rankings? The proposal is yes.
The alternative is that checkpoint carries only the task state, and
the resuming agent calls `garuda.briefing` fresh. The first is faster
but couples the three features; the second is slower but keeps them
independent.

### D13 — MCP surface expansion

Which HTTP routes become MCP tools in the next wave. The candidate
set is every read-only endpoint the dashboard uses. The decision is
which ones are worth the surface area.

### D14 — `audit_events` scoping

`audit_events` is currently scoped by tenant only. The question is
whether it should also be scoped by workspace, or whether the tenant
scope is the intended boundary.

### D15 — `generated.go` cleanup

`internal/selfdescribe/generated.go` contains stale generated content
from an earlier iteration. Decide whether to regenerate, delete, or
leave as reference.

---

## Beta program

Ten testers on the waitlist. Three are startup founders.

### Sequencing rule

Trust-floor queued items close before any tester is onboarded. **The
I-11 audit is now closed.** The two verification scripts that were
preconditions are closed (`scripts/runtime_contradiction_test.py`,
`scripts/doc_verify_test.py`). The doc → verify loop is proven
end-to-end on `go-validation-10`.

**The beta gate is now the MCP surface and the briefing tool.** Both
are tracked in the active work queue.

### What testers are told

The honest state. Go at Tier 5. Python and TypeScript at Tier 2. The
system analyses one language well and two languages structurally.
Runtime verification exists in code and is exercised against synthetic
spans. Production correlation is the beta question. Document ingestion
reads one specific format, documented in `docs/DOCUMENT_FORMATS.md`.
Ponytail is Alpha.

### What testers are asked to do (first hour)

1. Sign up at `http://<deployment>/signup`.
2. `garuda analyze <path> --save --workspace <name>` on their own
   repository.
3. Open `/dashboard`. Look at the entity count, the relationship
   count, and the drift panel.
4. Run one isolation probe against another tester's workspace name and
   confirm 404.
5. Report any number that disagrees with a query they can run
   themselves. The 404 probe is in the beta email so the tester can
   verify the isolation claim without trusting it.

### What "successful first hour" means

- The tester runs `garuda analyze` on their own repository.
- The dashboard loads with plausible numbers.
- The isolation probe returns 404.
- The tester reports one thing Garuda got wrong. That is expected and
  it is the point. A tester who reports nothing has not looked hard
  enough.

### What the beta does not cover

- Billing and plans
- SSO / OAuth
- Email verification
- Password reset
- Multi-tenant per user (a contractor working with two companies)
- Cross-tenant collaboration
- Per-workspace rate limits

### What the beta gates on

Before Session F (onboard), all of:

- Trust-floor queue closed and committed, or accepted with a recorded
  rationale.
- I-11 audit complete: 200 of 200 queries classified. **Closed.**
- Isolation tests 1–5 passing.
- CI green on main.
- Live deployment reachable from outside the laptop.

---

## Long-term vision

Garuda's long-term direction is to become a trusted intelligence
and integrity layer for complex digital systems.

That means expanding along one axis:

```
code  →  software systems  →  organizational software state  →  business-state integrity
```

The axis is not a pivot. Each step uses the same substrate — a
verified semantic model, a tri-state verification engine, and a
cryptographic trust layer — applied to a larger class of questions.

- **Code** is where the substrate is today. Entities, relationships,
  claims, evidence, verification, policy.
- **Software systems** is the direction of P5, P7, and P8. The same
  substrate applied across multiple repositories and correlated with
  runtime behaviour.
- **Organizational software state** is the direction of P6. The same
  substrate extended to capture decisions, intent, and the reasoning
  behind the code.
- **Business-state integrity** is the direction of P9. The same
  substrate applied to the invariants that govern critical business
  workflows — exactly-once semantics, valid state transitions, and
  traceable decisions.

Nothing in the vision requires a different product. It requires the
same product applied to a larger scope.

---

## The competitive wedge

Garuda is not competing on graph size, token savings, or hallucination
claims. The competitors who win those races have already made them
commodities.

Garuda competes on verification. The question Garuda answers is:
**does the software still match what the organization said it should
do, and can you prove it.**

Every phase above serves that question. Every gate above measures
progress toward it. Every queued item above is a defect in the current
answer, waiting to close.
```

### What changed in this pass

**Trust-floor closed list** now includes T35–T42 with commit hashes for the last five. The reader can see the full arc from T1 through T42 in one table instead of prose paragraphs.

**Trust-floor queued list** gained B15–B18 at the top, above the numbered backlog. The B-prefix items are the ones the audit surfaced and that are unresolved; they're distinct from the older numbered backlog and now sit in their own band.

**Sequencing rule** updated to reflect the audit's closure. The prior version stated "90 of 158, 68 remain." It now states the audit is closed and the beta gate is the MCP surface plus the briefing.

**I-11 audit section** rewritten as a closed arc with a final classification table covering all 200 queries across 15 batches, and a new "Arc conclusion" naming the nine instances of the "two sources of truth" pattern. This is the load-bearing paragraph — it's the reason the next AST lint rule exists.

**Active work queue** replaced with the four remaining items (audit closed, briefing, AST lint rule, MCP surface gap) and a "Closed this arc" table below it. The previous version had eight items, most of which were already done.

**Open decisions** gained D13, D14, D15.

**Beta program** updated: the sequencing rule now points at the MCP surface and briefing as the gate, not the audit.

### One thing to verify before you save

I assumed the T35–T37 items (checkpoint end-to-end, Merkle read-path fix, audit closure) correspond to commits you made between `b5ab860` and now. If any of those three have different commit hashes or different scope, adjust the T-table before you save the file. The T38–T42 hashes came directly from the file you shared. T31–T34 came from the existing roadmap. T35–T37 are the only ones I inferred from your earlier description of the arc, and they're the ones most likely to need correction.