# Garuda Tracking

**Backward-looking:** what closed, when, and how it was verified.  
**Forward-looking companion:** `docs/ROADMAP.md` and the active roadmap sources.  
**Status:** current-state reconciliation.  
**Last reviewed:** 2026-09-20.

> This tracker is authoritative for implementation status only when an item has a verification method. It is not a marketing document and does not promote a feature merely because a schema, route, type, or UI label exists.

---

## How to read this tracker

| Status | Meaning |
|---|---|
| **Closed** | Implementation and required verification are complete for the documented scope |
| **In flight** | Implementation exists or work is active, but required closure evidence is incomplete |
| **Queued** | Accepted work with no complete implementation |
| **Accepted** | Deliberately deferred or classified as a non-goal |
| **Blocked** | Cannot proceed until a dependency, decision, or validation prerequisite is resolved |

| Maturity | Meaning |
|---|---|
| Production (GA) | Authoritative within the named scope and backed by release evidence |
| Beta | Usable and verified, but constrained by language, scale, deployment, or validation depth |
| Experimental | Heuristic or exploratory; cannot silently override stronger evidence |
| Upcoming | Not shipped and must not be described as current functionality |

### Closure rules

1. Every closed item has an implementation location and a reproducible verification method.
2. A happy-path test is insufficient where uniqueness, concurrency, retries, scope, or lifecycle state matters.
3. Tests that may expose collisions must seed at least two tenants, tasks, runs, or relevant records.
4. Every mutating path must be checked for database failure, audit failure, retry behavior, and duplicate submission.
5. Tenant and workspace scope is part of the feature, not an afterthought.
6. Public claims must agree across README, PLAYBOOK, EVIDENCE, CAPABILITIES, SPECS, and current verifier output.
7. A patch is not written before the relevant source, tests, routes, migrations, callers, and current tracker state have been read.
8. Every implementation commit records the problem, implementation, verification, boundary, and tracker item.

---

## Current arc: operational hardening and evidence synchronization

The former tracker was last synchronized around the MCP surface expansion and lint arc. Since then, the following capabilities have been implemented and validated:

- Error-rate telemetry.
- Durable error logging.
- Request-ID ordering and propagation improvements.
- Query-latency percentiles through an in-process pgx tracer.
- Complete Operations dashboard panels.
- MCP session and tool-call tracking.
- Workspace Console surfaces.
- Current public specifications and evidence synchronization.
- Four-client MCP validation with the current 38/38 reference result.

Current operational commits include:

| Commit | Capability | Verification |
|---|---|---|
| `da253ad` | Operations error-rate counter | Operations-panel validation |
| `e0b0a99` | `errors_log` and Recent Errors panel | Build, runtime, and dashboard validation |
| `f244bae` | Request ID middleware ordering before logging | Request/error correlation validation |
| `58e1d35` | Query-latency P50/P95/P99 through pgx tracer | `go build ./...`, `go vet`, browser validation; 71 samples and no locked Operations cards |
| `5984121` | Public README, PLAYBOOK, SPECS, and subsystem documentation synchronization | `git diff --cached --check`, documentation review, pushed to `origin/main` |

---

## Current product boundary

Garuda is the software intelligence, evidence, and governance layer between AI agents and the software systems they change.

### Current capabilities

- Tenant- and workspace-scoped software state.
- Semantic entities and typed relationships.
- Go compiler-backed analysis within supported scope.
- Python and TypeScript structural analysis.
- Cross-repository workspace intelligence for supported dependency paths.
- Documentation ingestion and claim verification.
- Runtime observation ingestion and contradiction detection.
- Declarative policy evaluation.
- Merkle-backed evaluation and decision verification.
- 21-tool MCP surface.
- Cursor, Claude Desktop, Codex CLI, and dependency-free reference-verifier validation.
- MCP sessions and tool-call activity tracking.
- Transactional agent handoff, checkpoints, and resume.
- Token and execution budget accounting.
- Pre-flight classification and secret-like payload redaction.
- Workspace Console: Workspace, Agents, Governance, Decisions, Graph, and Evidence/Trust views.
- VS Code ledger, contradiction, diagnostics, graph, refresh, reanalysis, and Go-hover workflows.
- CI, CLI, HTTP/OpenAPI, dashboard, MCP, and IDE interfaces.
- Error-rate, durable-error, request-ID, and query-latency observability surfaces.

### Explicit non-goals or incomplete capabilities

- General-purpose agent runtime.
- OS-level execution sandbox.
- Full secrets manager or credential broker.
- Durable autonomous scheduler for future agent jobs.
- Complete model-provider gateway or model fleet orchestrator.
- Finished cross-agent shared memory.
- Universal real-time analysis on every file mutation.
- Universal semantic completeness across languages and dynamic behavior.

---

## Capability register

### Semantic analysis and graph

| Capability | Status | Evidence / verification |
|---|---|---|
| Go AST parsing | Closed / Production | `internal/analyzer/`, `internal/ast/`, Go validation corpora |
| Go compiler/type resolution | Closed / Production within scope | Named benchmark gates and Go-only corpus |
| Struct and field extraction | Closed / Production | Capability benchmark `V5` |
| Receiver disambiguation | Closed / Production | Benchmark `002-method-identity` |
| Interface implementation matching | Closed / Production | Benchmarks `003`, `009`, `010` |
| Generics and type parameters | Closed / Production | Benchmark `004-generics` |
| Aliases versus definitions | Closed / Production | Benchmark `005-alias` |
| Struct embedding | Closed / Production | Benchmark `006-embedding` |
| Variadic and closure handling | Closed / Production | Benchmarks `007`, `008` |
| Python structural analysis | Closed / Beta | Imports stronger than dynamic calls |
| TypeScript structural analysis | Closed / Beta | Structural/tree-sitter path; CGO required |
| Stable semantic identity | Closed | Canonical identity and persisted graph use |
| Typed relationships | Closed | Claims/relationship stores and consumers |
| Source evidence attribution | Closed | Source locations attached within supported paths |
| Graph exploration | Closed | CLI, MCP, dashboard, and VS Code surfaces |
| Blast-radius analysis | Closed | MCP/CLI cross-check; SQLModel 171 inbound edges |
| Decision-lineage impact | Closed for current path | Lineage and impact handlers |
| Cross-repository bridges | Closed / Beta | `cross_repo_edges`, multi-repository corpora, dashboard/briefing bridges |
| Cross-language resolution | Accepted boundary | Not claimed as compiler-backed; requires separate validation |

### Documentation and verification

| Capability | Status | Evidence / verification |
|---|---|---|
| Markdown ingestion | Closed | Document parser and CLI |
| ADR-style normative extraction | Closed | Document format contract and fixtures |
| Plain-text ingestion | Closed | Document parser |
| PDF/DOCX/RST ingestion | Closed for current parser path | Current ingestion implementation; corpus depth remains validation-sensitive |
| Claim normalization | Closed | Knowledge claim IR |
| `SUPPORTED` state | Closed | Documentation/runtime verification paths |
| `UNVERIFIED` state | Closed | Missing-evidence paths preserve uncertainty |
| `CONTRADICTED` state | Closed | Controlled contradiction test: 10/10 |
| Documentation-to-code drift | Closed for supported predicates | `docs verify`, evaluator, dashboard |
| Bidirectional drift views | Closed for current Console | Documentation claims and undocumented code views |
| Claim reversion after observation deletion | In flight | Requires lifecycle policy and tests |

### Runtime verification

| Capability | Status | Evidence / verification |
|---|---|---|
| Runtime observation ingestion | Closed | Runtime API and model |
| Telemetry span ingestion | Closed for tested path | `POST /api/v1/telemetry/spans` and controlled tests |
| Entity/runtime correlation | Closed for supported paths | Runtime correlator and verifier |
| Contradiction quarantine | Closed for controlled corpus | `runtime_contradiction_test.py`: 10/10 |
| Runtime verification-state distribution | Closed | Dashboard and database counts |
| `verification_missing` policy flow | Closed | Review policy and dashboard evidence |
| Autonomous continuous runtime verification | In flight | Requires automatic trigger/scheduling and MCP exposure |
| Production-scale runtime verification | In flight / Beta | Requires larger telemetry, throughput, retention, and recovery evidence |
| Dead-code detection | Queued | Ponytail arc |
| Unused-import detection | Queued | Ponytail arc |

### Policy and governance

| Capability | Status | Evidence / verification |
|---|---|---|
| Declarative YAML policies | Closed | Parser and evaluator |
| Five policy predicates | Closed | Evaluator and fixtures |
| `ALLOW`, `WARN`, `REVIEW`, `BLOCK` | Closed | CLI, dashboard, and CI outcomes |
| Preview evaluation | Closed | No persistence/no anchor |
| Committed evaluation | Closed | `--save` persistence and Merkle anchor |
| Reconcile evaluation | Closed | `--reconcile --save` supersedes missing policies |
| Authority attribution | Closed | Policy schema/evaluation records |
| Policy proof verification | Closed | CLI, dashboard, and MCP |
| Tenant/statement uniqueness | Closed | Migration and concurrent insert validation |
| Atomic policy supersession | In flight | B16: multi-call path requires one transaction |
| Preview/committed policy ID clarity | In flight | B27: document or distinguish synthesized IDs |

### Trust and integrity

| Capability | Status | Evidence / verification |
|---|---|---|
| Tenant-scoped Merkle roots | Closed | Merkle stores and vectors |
| Domain-separated hashing | Closed | Hash implementation and golden vectors |
| Inclusion proofs | Closed | Pure verifier functions and live anchors |
| Policy evaluation anchoring | Closed | `policy_evaluations` and `--save` |
| Decision revision-chain verification | Closed | Recorded evidence: 72 revisions across 17 decisions |
| Individual policy proof verification | Closed | `garuda policy verify` and MCP tool |
| Evidence and Trust dashboard | Closed | Browser validation and screenshots |
| Decision anchor workspace scoping | In flight | B23 final caller/path review |
| Merkle terminology and public boundary | Closed | Public docs use tamper-evident/verifiable wording |

### MCP and agent coordination

| Capability | Status | Evidence / verification |
|---|---|---|
| MCP stdio transport | Closed | JSON-RPC handshake |
| MCP protocol `2025-06-18` | Closed | Reference verifier |
| 21-tool registry | Closed | `cmd/garuda-mcp/main.go`, verifier |
| Graph, governance, claims, lineage, impact tools | Closed | Current tool registry and verifier coverage |
| Policy-proof verification tool | Closed | Unknown-evaluation and proof paths |
| Handoff tool | Closed | MCP happy/negative paths and store tests |
| Resume tool | Closed | Single-consumption and negative paths |
| Notification suppression | Closed | Protocol verification |
| Structured unknown-tool errors | Closed | JSON-RPC `-32601` |
| MCP session tracking | Closed | `mcp_sessions`, `mcp_tool_calls`, activity views |
| Tool-call argument whitelist | Closed | Whitelist path and privacy boundary |
| Graceful session close | Closed | Shutdown write path |
| Stale-session cleanup | Queued | Schema/index/spec exists; job and verification remain |
| Session pruning | Queued | Retention job and `job_state` closure remain |
| Handoff lineage edge persistence | In flight | Open gap: handoff path does not write `lineage_edges` |
| HTTP/MCP handoff error parity | In flight | B33: HTTP collapses detailed store errors |
| Cross-agent shared memory | Queued | A12 |
| Engineering-state portability | Queued | A9 |

### Workspace Console and IDE

| Capability | Status | Evidence / verification |
|---|---|---|
| Workspace intelligence view | Closed | Browser validation |
| Workspace KPIs | Closed | Repositories, packages, entities, relationships, policies, drift |
| Language breakdown | Closed | Dashboard rendering |
| Architectural hubs | Closed | Dashboard rendering |
| Recent evidence ledger | Closed | Dashboard panel |
| Agents/session view | Closed | MCP session and tool-call activity |
| Governance view | Closed | Policies, claims, drift, contradictions, trust |
| Decisions view | Closed | Decision history, details, lineage, revisions |
| Graph view | Closed | Interactive topology, communities, level controls |
| Evidence and Trust view | Closed | Root, block, parent/genesis, verification controls |
| VS Code activation/build | Closed | Extension manifest and compile path |
| VS Code ledger view | Closed | Screenshot validation |
| VS Code contradiction view | Closed | Screenshot validation |
| VS Code Problems diagnostics | Closed for tested diagnostics | `diagnosticsProvider.ts`, observed `ARCH_DRIFT_001` findings |
| VS Code graph visualizer | Closed | Command contribution and validation |
| VS Code AST reanalysis | Closed | Command contribution and validation |
| VS Code ledger refresh | Closed | Command contribution and validation |
| VS Code Go hover impact | Closed for configured path | Hover provider and setting |
| Unrestricted file-save real-time analysis | Accepted boundary | Refresh/reanalysis/event-driven behavior only |
| IDE Ponytail diagnostics | Queued | After Ponytail core output contract |

### Operational observability

| Capability | Status | Evidence / verification |
|---|---|---|
| Request IDs | Closed | Middleware ordering fix `f244bae` |
| Durable error log | Closed | `errors_log`, slog handler, Recent Errors panel `e0b0a99` |
| MCP error-rate counter | Closed | `da253ad` and Operations panel |
| Query latency percentiles | Closed | `58e1d35`; pgx tracer, P50/P95/P99, 71 samples |
| Graceful telemetry drain | Closed | Runtime shutdown log |
| Gateway shutdown completion | Closed | Runtime shutdown log |
| Operations dashboard panels | Closed | Browser validation: no locked cards |
| Error request-ID propagation | In flight | B46: convert handler logs to context-aware slog calls |
| Stale-session marking | Queued | `mcp_sessions.mark_stale` job |
| Session/tool-call pruning | Queued | `mcp_sessions.prune` job |
| Long-term metrics retention | Queued | Aggregation/retention design |

### Security, identity, and resource controls

| Capability | Status | Evidence / verification |
|---|---|---|
| Authenticated sessions | Closed for current API scope | Auth service, session middleware, login/signup |
| Tenant membership | Closed for current scope | Membership migration and signup path |
| Workspace membership | Closed for current scope | Membership migration and workspace access tests |
| Tenant/workspace isolation | Closed for documented access paths | I-11 audit, isolation tests, negative-path tests |
| Request-scoped workspace resolution | Closed | Workspace scope tests |
| Token budgeting | Closed | Budget store/handlers and ledger |
| Execution budgeting | Closed | Budget consumption path |
| Pre-flight classification | Closed for current classifier | Router and classification path |
| Secret-like payload redaction | Closed for current pattern set | Shield/redaction implementation |
| Full credential broker | Accepted non-goal | Separate security arc required |
| OS/container execution sandbox | Accepted non-goal | Separate runtime-security arc required |
| Durable scheduled agent execution | Queued | Separate scheduler arc |

---

## Arc status

### A0–A7: completed foundation and product surfaces

**Status:** Closed for documented scope.

These arcs cover semantic analysis, workspace persistence, tenant/workspace isolation, documentation verification, runtime evidence, Merkle integrity, policy governance, MCP, agent coordination, dashboards, VS Code, and current observability panels.

### A8: Ponytail static hygiene

**Status:** Next implementation arc — queued.

Ponytail must be treated as a separate static-analysis product arc, not a quick MCP wrapper. Before implementation, read:

- `internal/analyzer/`.
- `internal/ast/`.
- `internal/graph/`.
- `internal/impact/`.
- `tools/lint/`.
- `cmd/garuda-mcp/main.go`.
- `vscode-extension/src/diagnosticsProvider.ts`.
- Relevant migrations, store methods, fixtures, and current evidence files.

Required output classes:

- Unused symbols.
- Unused imports.
- Over-scoped files/packages.
- Dead routes where statically defensible.
- Confidence and evidence for every finding.
- Suppression and explanation path.
- CLI, MCP, CI, and later IDE output.

Required guardrail: `UNVERIFIED` or runtime-unobserved must never be relabelled as dead code automatically.

### A9: Agent Continuity and Portable Engineering State

**Status:** Queued; separate product arc.

The objective is not transcript migration. It is portable engineering-state recovery across agents and providers.

Required first experiment:

1. Select ten representative tasks.
2. Let a source agent perform or develop the task.
3. Persist the resulting Garuda state.
4. Remove the source agent.
5. Give a destination agent only the repository and Garuda-derived context package.
6. Measure completion, correctness, human scaffolding, rediscovery, policy adherence, and time to productivity.

Do not claim a fixed context-transfer percentage before this benchmark exists.

### A10: Autonomous Runtime Verification

**Status:** In flight.

Existing: ingestion, correlation, contradiction creation, dashboard presentation, `verification_missing`, and controlled 10/10 contradiction evidence.

Remaining:

- Autonomous trigger/scheduler.
- Idempotency and replay semantics.
- Runtime-verification MCP tool.
- Evidence freshness and expiry.
- Contradiction lifecycle and resolution.
- Worker restart/retry behavior.
- Dashboard/IDE convergence tests.

### A11: Scale and release hardening

**Status:** In flight.

Remaining:

- 10-, 25-, and 100-plus repository gates.
- Runtime throughput and retention tests.
- Multi-tenant concurrent access.
- Double-approve and duplicate-write races.
- Ghost expiry and stale-session behavior.
- Database/registry outage fail-closed paths.
- Workspace deletion and child-row cleanup.
- Migration duplicate-prefix cleanup.
- Production API/bootstrap parity.
- Documentation synchronization automation.

### A12: Shared memory and context compression

**Status:** Queued.

Requires:

- Workspace-keyed memory ownership.
- Provenance and evidence tier.
- Read/write authorization.
- Revocation and expiry.
- Compression summaries with source links.
- Conflict and contradiction handling.
- MCP and dashboard surfaces.

### A13: Durable agent scheduling

**Status:** Queued; separate runtime arc.

Requires:

- Durable job model.
- Schedule and lease semantics.
- Retry, timeout, cancellation, and dead-letter behavior.
- Persistent agent-loop state.
- Resource budgets and attribution.
- Tenant/workspace authorization.
- Recovery after process/session closure.

### A14: Credential and execution security

**Status:** Accepted non-goal for current release; separate security arc if product scope changes.

Requires:

- Credential broker or external secret-manager contract.
- Per-tenant and per-agent authorization.
- Rotation and revocation.
- Redaction and audit.
- Filesystem/network/process isolation.
- Escape and exfiltration testing.

---

## Current open findings

| ID | Finding | Severity | Status | Arc |
|---|---|---:|---|---|
| B1 | Supported claims do not revert when observations are deleted | Medium | Open | A10 |
| B3 | Duplicate migration numeric prefixes | Medium | Open | A11 |
| B4 | Capability/evidence documents can become stale | Medium | Open | A11 |
| B11 | Runtime correlation by name is ambiguous for duplicated names | Medium | Open | A10 |
| B15 | `audit_events` lacks direct `tenant_id` scope | Medium | Open | A11 |
| B16 | Policy supersession not fully atomic across all state changes | Medium | Open | A5 hardening |
| B23 | Decision anchor verification final scope review | Low | Open | A5 hardening |
| B33 | HTTP handoff errors less specific than MCP errors | Medium | Open | A5 hardening |
| B34 | Duplicate `(user_id, tenant_id)` membership rows possible | Medium | Open | A2 hardening |
| B35 | Workspace picker does not expose all tenant workspaces | Medium | Open | A2/UI |
| B39 | Reference verifier sessions visually pollute Agents view | Low | Open | A7 |
| B40 | Append-only Merkle history remains after workspace deletion | Low | Accepted historical behavior pending query decision | A11 |
| B41 | Workspace deletion leaves repository rows | Medium | Open | A11 |
| B42 | CLI workspace creation membership initialization | Medium | Open | A2 |
| B43 | Decisions are tenant-scoped while dashboard is workspace-oriented | Medium | Open/design decision | A2 |
| B44 | Orphan workspaces from test-tenant cleanup | Medium | Open | A11 |
| B46 | Handler logs do not consistently use request-aware slog calls | Low | Open | A7 |
| B47 | Pool creation should share one traced-pool constructor | Low | Open | A7 |
| B48 | `mcp_sessions.request_count` counts tool attempts, not all requests | Low | Open/cosmetic | A7 |
| B49 | MCP initialize/tools-list requests are not included in request count | Low | Open | A7 |
| B50 | Stale-session and pruning jobs are specified but not implemented | Medium | Open | A7 |
| B51 | Handoff completion does not persist a `lineage_edges` row | Medium | Open | A5 |
| B52 | Public historical documents still contain obsolete MCP totals | Low | Open | A11 |
| B53 | Production API bootstrap path differs from `garuda dev` bootstrap path | Medium | Open | A11 |
| B54 | Test-created tenants/workspaces require isolated test database or cleanup | Medium | Open | A11 |
| B55 | Control Plane/internal operational surface must remain excluded from tenant-facing claims | Low | Accepted documentation boundary | A11 |
| B56 | Portable engineering-state export contract does not exist yet | High for A9, not current-product defect | Queued | A9 |
| B57 | Ponytail finding schema and confidence contract do not exist yet | High for A8, not current-product defect | Queued | A8 |
A8.1 Garuda Hygiene report foundation — In flight
Existing Ponytail CLI — Existing foundation, semantic hardening required
Static unreferenced candidates — Existing behavior, relabeling required
Duplicate symbol names — Existing behavior, terminology correction required
Standard-library alternatives — Existing advisory behavior
Typed Hygiene finding model — Planned in A8.1
garuda hygiene command — Planned in A8.1
garuda ponytail compatibility alias — Planned in A8.1
Hygiene MCP adapter — Queued for A8.2
Hygiene VS Code diagnostics — Queued for A8.2
Autonomous Hygiene refresh — Queued under autonomy, not A8.1

A8.1 — Garuda Hygiene report foundation

Status: In flight

Current foundation:
- cmd/garuda/ponytail.go exists.
- It reads tenant/workspace-scoped entities and graph data.
- It reports zero-incoming candidates, duplicate names, and standard-library suggestions.
- No dedicated Ponytail tests exist.
- No persisted finding lifecycle exists.
- No MCP or VS Code Hygiene adapter exists.

A8.1 scope:
- Introduce typed advisory finding semantics.
- Rename classifications internally:
  STATIC_UNREFERENCED_CANDIDATE
  DUPLICATE_SYMBOL_NAME
  STANDARD_LIBRARY_ALTERNATIVE
- Add a reusable report core.
- Add preferred `garuda hygiene` command behavior.
- Preserve `garuda ponytail` compatibility.
- Preserve tenant/workspace scope.
- Keep the first version report-only and non-mutating.
- Add deterministic unit and CLI tests.

Explicit non-goals:
- No authoritative DEAD_CODE_CONFIRMED state.
- No database findings table.
- No MCP tool.
- No autonomous execution.
- No VS Code diagnostics.
- No automatic source deletion.
- No policy blocking.

Exit criteria:
- Human and JSON output are semantically identical.
- Findings are deterministic.
- Scope isolation tests pass.
- False-positive guard tests pass.
- Build, vet, focused tests, and CLI runs pass.

Existing Ponytail CLI foundation — Existing; semantic hardening required
Store entity scan correctness — Closed; ded510a
Static unreferenced candidate classification — In flight
Duplicate symbol-name classification — In flight
Standard-library suggestions — Advisory classification
Typed Hygiene finding model — Planned
garuda hygiene preferred command — Planned
garuda ponytail compatibility path — Planned
MCP Hygiene adapter — Queued
VS Code Hygiene diagnostics — Queued
Autonomous Hygiene refresh — Queued under autonomy

### Resolved findings carried forward

| Finding | Resolution |
|---|---|
| Cross-tenant workspace resolution leak | Fixed and verified through tenant-scoped resolution tests |
| Workspace-scoped read-path defects | Closed through I-11 audit and regression tests |
| Cross-repository bridge read-path mismatch | Fixed to read authoritative `cross_repo_edges` data |
| Missing briefing cross-repository bridge count | Fixed and verified in briefing output |
| Handoff checkpoint name collision | Fixed by unique checkpoint naming and two-handoff regression test |
| Invalid impact target panic | Fixed with clean validation and non-zero exit behavior |
| MCP notification response bug | Fixed and verified by protocol test |
| MCP tool-surface expansion | 21 tools and current 38/38 reference verification |
| Error-rate Operations panel | Shipped and verified |
| Durable error log panel | Shipped and verified |
| Request-ID middleware ordering | Fixed and verified |
| Query-latency percentile panel | Shipped and verified with 71 samples |
| Documentation synchronization commit | Current docs synchronized in commit `5984121`; remaining historical references are tracked as B52 |

---

## Evidence synchronization gates

Run before public documentation or release commits:

```bash
grep -RniE \
  "36/36|18/18|19/19|MCP-21.*36|MCP-21.*18" \
  README.md PLAYBOOK.md EVIDENCE.md docs/SPECS.md docs/CAPABILITIES.md \
  || true
```

Run current MCP verification:

```bash
WORKSPACE=go-validation-10 python3 scripts/mcp_verify.py
```

Expected:

```text
═══ 38/38 checks passed ═══
```

Public documentation must agree on:

- Current release and branch status.
- MCP tool count.
- Current reference-verifier count.
- Verified client list.
- Analyzer maturity.
- Current versus upcoming capabilities.
- Evidence scope and limitations.

---

## Commit discipline

Every implementation or documentation commit must include:

1. A scoped imperative subject line.
2. The problem being solved.
3. The implementation or documentation change.
4. The verification commands and falsifiable result.
5. Explicit boundaries and non-goals.
6. Tracker ID and arc reference.

Recommended structure:

```text
<scope>: <short imperative summary>

Problem:
...

Implementation:
...

Verification:
...

Boundaries:
...

Tracker:
Arc A<id>; item <id>
```

No item is closed until the tracker is updated after the verification run.

---

## Immediate next action

The next implementation arc remains **A8 — Ponytail Static Hygiene**.

Before writing any Ponytail patch, read the analyzer, graph, impact, lint, MCP registry, VS Code diagnostics, migrations, store methods, fixtures, and current evidence files. Define the finding schema and confidence contract first. Do not add a tool or UI route before the underlying finding semantics and negative-path tests exist.

Agent Continuity is **A9 — queued** and must not be mixed into Ponytail implementation. Any export package, destination adapter, context-recovery score, or vendor-neutral state exchange belongs to A9 and requires a separate design and benchmark arc.


### QUEUED ITEM GARUDA HYGINE

A8.3 Command Contract Hardening Plan
Goal
Harden the new garuda hygiene command and its deprecated garuda ponytail alias before adding MCP, persistence, VS Code integration, or autonomy.

Scope
This pass should be test- and contract-focused:

Assert canonical and compatibility commands expose the same report contract.

Preserve the legacy stdlib_alternatives JSON field.

Exercise empty and malformed-input cases in the pure Hygiene core.

Verify deterministic output.

Verify tenant/workspace scoping at the store boundary using existing store tests and fixtures.

Verify the report path is read-only.

Replace or narrow the untyped graph-edge boundary where practical without changing the current external CLI behavior.

Dependabot is intentionally out of scope.

Important distinction
The current garuda hygiene command is an adapter over the existing store APIs. The pure internal/hygiene package can be tested without PostgreSQL. The CLI handler currently performs database reads directly, so command-level tests should not require a new database mocking layer unless the repository already has one.

Do not invent an interface solely for this pass. First inspect existing store test seams and use the smallest compatible seam.

First inspection commands
bash
grep -R "func .*Ponytail\|func .*Hygiene\|hygieneCmd\|ponytailCmd\|handleHygiene\|GetGraphData\|ListEntities" -n cmd/garuda internal

grep -R "func Test.*Scope\|TenantIsolation\|workspace_id\|GetGraphData\|ListEntities" -n internal/store cmd/garuda --include='*_test.go'

find cmd/garuda internal/hygiene internal/store -name '*_test.go' -maxdepth 4 -print
Tests to add or extend
Pure Hygiene tests
Add focused cases in internal/hygiene/analyze_test.go:

Empty entities and relationships return zero counts and no findings.

Empty names do not create duplicate-name findings.

Package and file entities are excluded from static unreferenced candidates.

A referenced entity is not reported as a static unreferenced candidate.

A zero-incoming symbol is reported as a candidate with advisory wording.

Duplicate names are aggregated deterministically by name and package.

Same name in one package does not produce a duplicate-package finding.

Contains suggestions use slices.Contains.

Sort suggestions use slices.Sort.

Mixed Contains/Sort names produce the correct single or combined suggestion.

Findings are sorted deterministically.

Relationship count reflects accepted typed relationships supplied to the analyzer.

Use table-driven tests where cases share setup. Assert complete finding records where practical, not only counts.

Adapter tests
Test the graph conversion helper directly if it remains a package-level helper:

Valid {from,to,type} maps convert correctly.

Missing from, to, or type are skipped.

Non-string values are skipped without panic.

Empty identifiers are skipped.

Input order is preserved by the conversion helper; deterministic sorting belongs to hygiene.Analyze.

If the repository standard permits unexported helper tests in package garuda, use that. Otherwise move the conversion into a small internal package only if necessary.

Command compatibility tests
Prefer an existing CLI test harness. If none exists, do not add a database mock in this pass. Instead:

Keep the already verified real-workspace parity command as the integration check.

Add pure command-construction tests that verify both commands have the same flags and argument validation.

Verify hygieneCmd.Use is hygiene [path].

Verify ponytailCmd.Use is ponytail [path].

Verify ponytailCmd.Deprecated is non-empty and points to garuda hygiene.

Verify both commands expose json and output flags.

If a command factory is used, test the factory rather than Cobra global state.

Read-only guarantee
The current report path calls only:

Workspace resolution.

ListEntities.

GetGraphData.

It must not call insert, update, delete, anchor, or persistence APIs. Confirm this by code inspection and by existing store/API tests. Do not add a write transaction merely to prove that no write occurs.

Scoping guarantee
The command must continue resolving the workspace under the active tenant before reading entities and edges. Add or reuse a store test proving that two tenants with similarly named workspaces cannot cross-resolve.

The minimum useful assertion is:

text
same workspace name + different tenant => tenant-local workspace or explicit not-found
Never accept a test that only uses one tenant; that proves existence, not isolation.

Typed graph boundary
The current adapter accepts []map[string]interface{} because that is the existing GetGraphData contract. Do not change the store API and CLI contract in the same patch unless the existing tests make the change low-risk.

A safe incremental approach is:

Keep GetGraphData unchanged.

Keep hygieneRelationships as the compatibility adapter.

Add malformed-map tests.

Record typed graph-edge migration as a follow-up if the store contract is broad.

Verification commands
bash
gofmt -d cmd/garuda/ponytail.go internal/hygiene/*.go

go test ./internal/hygiene/... -count=1
go test ./internal/store/... ./cmd/garuda/... -count=1
go test ./... -count=1
go build ./...
go vet ./internal/hygiene/... ./internal/store/... ./cmd/garuda/...
go build -o ./bin/garuda ./cmd/garuda
Integration parity:

bash
GARUDA_WORKSPACE=go-validation-10 \
GARUDA_TENANT_ID=00000000-0000-0000-0000-000000000001 \
./bin/garuda hygiene . --json -o /tmp/garuda-hygiene.json

GARUDA_WORKSPACE=go-validation-10 \
GARUDA_TENANT_ID=00000000-0000-0000-0000-000000000001 \
./bin/garuda ponytail . --json -o /tmp/garuda-ponytail.json

diff -u \
  <(jq -S . /tmp/garuda-hygiene.json) \
  <(jq -S . /tmp/garuda-ponytail.json)
Compatibility field check:

bash
jq 'keys, .summary, .total_entities, .total_relationships' \
  /tmp/garuda-hygiene.json
Expected top-level keys include:

text
dead_code
duplications
stdlib_alternatives
summary
total_entities
total_relationships
Commit boundary
Recommended commit:

text
hygiene: harden command compatibility and report contracts
Keep this separate from any MCP or persistence work.

Follow-up after A8.3
Only after this contract pass is green should the next arc begin:

Expose a read-only Hygiene MCP tool, if the MCP surface is still desired.

Define a stable MCP input/output schema from the existing report contract.

Add persistence only after deciding whether findings are snapshots, observations, or ephemeral analysis results.

Add VS Code diagnostics only after severity, identity, suppression, and lifecycle semantics are specified.

Current Hygiene status
Completed:

Pure internal/hygiene analyzer.

Advisory finding model.

Static unreferenced candidates.

Duplicate-name aggregation.

Standard-library suggestions.

Deterministic finding ordering.

Input immutability tests.

Empty-input tests.

Package/file exclusion tests.

Duplicate aggregation tests.

Malformed graph-edge handling.

Canonical garuda hygiene command.

Deprecated garuda ponytail compatibility alias.

Legacy JSON field preservation.

CLI parity verification.

Full repository tests, build, and vet.

Three Hygiene commits pushed:

8e2f4dc

f644b25

a8eb530

