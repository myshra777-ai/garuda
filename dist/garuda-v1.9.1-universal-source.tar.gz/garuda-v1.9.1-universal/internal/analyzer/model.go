// Copyright 2026 Rohit Mishra
// SPDX-License-Identifier: Apache-2.0
//
// Law Enforcement. I am bound by the ACGM Resolution Invariant and the 10 Immutable Laws. Truth Preservation is Absolute.

package analyzer

import "time"

// EntityKind defines the type of a semantic entity.
type EntityKind string

const (
	KindRepository EntityKind = "repository"
	KindDirectory  EntityKind = "directory"
	KindFile       EntityKind = "file"
	KindPackage    EntityKind = "package"
	KindClass      EntityKind = "class"
	KindStruct     EntityKind = "struct"
	KindInterface  EntityKind = "interface"
	KindFunction   EntityKind = "function"
	KindMethod     EntityKind = "method"
	KindVariable   EntityKind = "variable"
	KindConstant   EntityKind = "constant"
	KindType       EntityKind = "type"
	KindAlias      EntityKind = "alias"
	KindExternal   EntityKind = "external"
)

// RelationshipType defines the type of a relationship.
type RelationshipType string

const (
	RelContains   RelationshipType = "CONTAINS"
	RelDefines    RelationshipType = "DEFINES"
	RelImports    RelationshipType = "IMPORTS"
	RelCalls      RelationshipType = "CALLS"
	RelReferences RelationshipType = "REFERENCES"
	RelImplements RelationshipType = "IMPLEMENTS"
	RelEmbeds     RelationshipType = "EMBEDS"
	RelDependsOn  RelationshipType = "DEPENDS_ON"
)

// Entity represents a discovered type, container, or function.
type Entity struct {
	ID           string     `json:"id"`
	Kind         EntityKind `json:"kind"`
	Name         string     `json:"name"`
	Package      string     `json:"package"`
	ModulePath   string     `json:"module_path,omitempty"`
	PackagePath  string     `json:"package_path,omitempty"`
	ReceiverType string     `json:"receiver_type,omitempty"`
	File         string     `json:"file"`
	Line         int        `json:"line"`
	LineStart    int        `json:"line_start"`
	LineEnd      int        `json:"line_end"`
	Exported     bool       `json:"exported"`
	Language     string     `json:"language,omitempty"`
	Fields       []Field    `json:"fields,omitempty"`
	Methods      []Method   `json:"methods,omitempty"`
	Signature    string     `json:"signature,omitempty"`
	Comments     string     `json:"comments,omitempty"`
}

// Field represents a struct field or interface method parameter.
type Field struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	Tag         string `json:"tag,omitempty"`
	JSONTag     string `json:"json_tag,omitempty"`
	DBTag       string `json:"db_tag,omitempty"`
	ValidateTag string `json:"validate_tag,omitempty"`
	Comment     string `json:"comment,omitempty"`
	IsPointer   bool   `json:"is_pointer"`
	IsSlice     bool   `json:"is_slice"`
	LineStart   int    `json:"line_start"`
	LineEnd     int    `json:"line_end"`
}

// Method represents a method on a struct or interface.
type Method struct {
	Name       string   `json:"name"`
	Signature  string   `json:"signature"`
	Parameters []string `json:"parameters,omitempty"`
	Returns    []string `json:"returns,omitempty"`
	IsExported bool     `json:"is_exported"`
	LineStart  int      `json:"line_start"`
	LineEnd    int      `json:"line_end"`
}

// Evidence anchors a relationship claim to source code and provenance.
type Evidence struct {
	File      string `json:"file"`
	Line      int    `json:"line,omitempty"`
	LineStart int    `json:"line_start,omitempty"`
	LineEnd   int    `json:"line_end,omitempty"`
	Commit    string `json:"commit,omitempty"`
	Analyzer  string `json:"analyzer,omitempty"`
	Snapshot  string `json:"snapshot,omitempty"`
}

// Relationship represents a semantic dependency between entities.
type Relationship struct {
	From             string   `json:"from"`
	To               string   `json:"to"`
	Type             string   `json:"type"`
	Confidence       float64  `json:"confidence,omitempty"`
	ResolutionStatus string   `json:"resolution_status,omitempty"`
	ResolutionMethod string   `json:"resolution_method,omitempty"`
	EpistemicClass   string   `json:"epistemic_class,omitempty"`
	Evidence         Evidence `json:"evidence,omitempty"`
}

// Stats holds high-level extraction metrics and type-checking completeness metadata.
type Stats struct {
	Files            int  `json:"files"`
	Packages         int  `json:"packages"`
	Structs          int  `json:"structs"`
	Interfaces       int  `json:"interfaces"`
	Functions        int  `json:"functions"`
	Imports          int  `json:"imports"`
	TotalFields      int  `json:"total_fields"`
	TypeErrors       int  `json:"type_errors,omitempty"`
	AnalysisComplete bool `json:"analysis_complete"`
}

// Result is the top-level analysis container.
type Result struct {
	Entities        []Entity       `json:"entities"`
	Relationships   []Relationship `json:"relationships"`
	Fingerprint     string         `json:"fingerprint,omitempty"`
	AnalyzedAt      time.Time      `json:"analyzed_at"`
	Package         string         `json:"package,omitempty"`
	Source          string         `json:"source,omitempty"`
	Stats           Stats          `json:"stats"`
	TypeDiagnostics []string       `json:"type_diagnostics,omitempty"`
	BuildContext    *BuildContext  `json:"build_context,omitempty"`
}

// RevisionSummary is the lightweight summary stored in canonical revisions.
type RevisionSummary struct {
	Fingerprint  string        `json:"fingerprint"`
	Stats        Stats         `json:"stats"`
	PayloadHash  string        `json:"payload_hash"`
	Provenance   Provenance    `json:"provenance,omitempty"`
	Source       string        `json:"source,omitempty"`
	Entities     int           `json:"entities"`
	Claims       int           `json:"claims"`
	BuildContext *BuildContext `json:"build_context,omitempty"`
}

// Provenance tracks source metadata and execution context.
type Provenance struct {
	WorkspaceID    string   `json:"workspace_id,omitempty"`
	RepositoryID   string   `json:"repository_id,omitempty"`
	CommitSHA      string   `json:"commit_sha,omitempty"`
	SourcePath     string   `json:"source_path,omitempty"`
	TargetPlatform string   `json:"target_platform,omitempty"`
	BuildTags      []string `json:"build_tags,omitempty"`
	CGOEnabled     bool     `json:"cgo_enabled,omitempty"`
}

// ----------------------------------------------------------------------------
// Diff-related types
// ----------------------------------------------------------------------------

// DiffReport holds the complete semantic diff result.
type DiffReport struct {
	StatsDiff         StatsDiff          `json:"stats_diff"`
	FingerprintDiff   FingerprintDiff    `json:"fingerprint_diff"`
	EntityDiffs       []EntityDiff       `json:"entity_diffs"`
	RelationshipDiffs []RelationshipDiff `json:"relationship_diffs"`
	Summary           DiffSummary        `json:"summary"`
}

// StatsDiff shows numeric metric changes.
type StatsDiff struct {
	Files       int `json:"files"`
	Packages    int `json:"packages"`
	Structs     int `json:"structs"`
	Interfaces  int `json:"interfaces"`
	Functions   int `json:"functions"`
	Imports     int `json:"imports"`
	TotalFields int `json:"total_fields"`
}

// FingerprintDiff shows if graph fingerprints match.
type FingerprintDiff struct {
	Before string `json:"before"`
	After  string `json:"after"`
	Match  bool   `json:"match"`
}

// EntityDiff represents a change to an entity.
type EntityDiff struct {
	EntityID    string       `json:"entity_id"`
	Kind        EntityKind   `json:"kind"`
	Name        string       `json:"name"`
	File        string       `json:"file"`
	Status      string       `json:"status"`
	FieldsDiff  *FieldsDiff  `json:"fields_diff,omitempty"`
	MethodsDiff *MethodsDiff `json:"methods_diff,omitempty"`
	Impact      int          `json:"impact"`
}

// FieldsDiff shows struct field changes.
type FieldsDiff struct {
	Added    []Field     `json:"added"`
	Removed  []Field     `json:"removed"`
	Modified []FieldDiff `json:"modified"`
}

// FieldDiff shows a field modification (before/after).
type FieldDiff struct {
	Name   string `json:"name"`
	Before Field  `json:"before"`
	After  Field  `json:"after"`
}

// MethodsDiff shows receiver method changes.
type MethodsDiff struct {
	Added   []Method `json:"added"`
	Removed []Method `json:"removed"`
}

// RelationshipDiff represents a change to a relationship edge.
type RelationshipDiff struct {
	From   string           `json:"from"`
	To     string           `json:"to"`
	Type   RelationshipType `json:"type"`
	Status string           `json:"status"`
}

// DiffSummary provides a high-level overview of detected changes.
type DiffSummary struct {
	BreakingChanges int `json:"breaking_changes"`
	Warnings        int `json:"warnings"`
	Additions       int `json:"additions"`
	Removals        int `json:"removals"`
	Modified        int `json:"modified"`
}
