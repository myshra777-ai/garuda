// Copyright 2026 Rohit Mishra
// SPDX-License-Identifier: Apache-2.0
//
// Law Enforcement. I am bound by the ACGM Resolution Invariant and the 10 Immutable Laws. Truth Preservation is Absolute.

package store

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/google/uuid"
)

var ErrWorkspaceExists = errors.New("workspace with this name already exists")

type Workspace struct {
	ID          uuid.UUID `json:"id"`
	TenantID    uuid.UUID `json:"tenant_id"`
	Name        string    `json:"name"`
	RootPath    string    `json:"root_path"`
	IsGoWork    bool      `json:"is_go_work"`
	Description string    `json:"description"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// getTenantIDFromWorkspace retrieves the tenant ID for a given workspace.
func (s *PostgresStore) getTenantIDFromWorkspace(ctx context.Context, workspaceID uuid.UUID) (uuid.UUID, error) {
	var tenantID uuid.UUID
	err := s.pool.QueryRow(ctx, `SELECT tenant_id FROM workspaces WHERE id = $1`, workspaceID).Scan(&tenantID)
	if err != nil {
		return uuid.Nil, fmt.Errorf("failed to get tenant ID for workspace: %w", err)
	}
	return tenantID, nil
}

// CreateWorkspace creates a new workspace or returns existing one.
func (s *PostgresStore) CreateWorkspace(ctx context.Context, tenantIDStr, name, description string) (*Workspace, error) {
	tenantID, err := uuid.Parse(tenantIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid tenant UUID: %w", err)
	}

	var (
		id        uuid.UUID
		rootPath  string
		isGoWork  bool
		createdAt time.Time
		updatedAt time.Time
		inserted  bool
	)

	query := `
		INSERT INTO workspaces (id, tenant_id, name, root_path, is_go_work, description, created_at, updated_at)
		VALUES ($1, $2, $3, '.', false, $4, NOW(), NOW())
		ON CONFLICT (tenant_id, name) DO UPDATE
			SET name = EXCLUDED.name
		RETURNING id,
		          COALESCE(root_path, '.'),
		          is_go_work,
		          created_at,
		          updated_at,
		          (xmax = 0) AS inserted;
	`

	newID := uuid.New()
	err = s.pool.QueryRow(ctx, query, newID, tenantID, name, description).Scan(
		&id, &rootPath, &isGoWork, &createdAt, &updatedAt, &inserted,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to execute create workspace query: %w", err)
	}

	// Automatically grant existing tenant owners/members access to this workspace
	// so CLI-created workspaces are immediately visible in the web dashboard.
	_, _ = s.pool.Exec(ctx, `
		INSERT INTO workspace_members (user_id, workspace_id, role, created_at)
		SELECT tm.user_id, $1, CASE WHEN tm.role IN ('owner', 'admin') THEN tm.role ELSE 'member' END, NOW()
		  FROM tenant_members tm
		 WHERE tm.tenant_id = $2
		ON CONFLICT (user_id, workspace_id) DO NOTHING
	`, id, tenantID)

	ws := &Workspace{
		ID:          id,
		TenantID:    tenantID,
		Name:        name,
		RootPath:    rootPath,
		IsGoWork:    isGoWork,
		Description: description,
		CreatedAt:   createdAt,
		UpdatedAt:   updatedAt,
	}

	if !inserted {
		return ws, ErrWorkspaceExists
	}

	return ws, nil
}

// ListWorkspaces lists all workspaces for a tenant.
func (s *PostgresStore) ListWorkspaces(ctx context.Context, tenantIDStr string) ([]*Workspace, error) {
	tenantID, err := uuid.Parse(tenantIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid tenant UUID: %w", err)
	}

	rows, err := s.pool.Query(ctx, `
		SELECT id, tenant_id, name, COALESCE(root_path, '.'), is_go_work, COALESCE(description, ''), created_at, updated_at
		FROM workspaces WHERE tenant_id = $1 ORDER BY name ASC
	`, tenantID)
	if err != nil {
		return nil, fmt.Errorf("failed to query workspaces: %w", err)
	}
	defer rows.Close()

	var workspaces []*Workspace
	for rows.Next() {
		var w Workspace
		if err := rows.Scan(&w.ID, &w.TenantID, &w.Name, &w.RootPath, &w.IsGoWork, &w.Description, &w.CreatedAt, &w.UpdatedAt); err != nil {
			return nil, fmt.Errorf("failed to scan workspace: %w", err)
		}
		workspaces = append(workspaces, &w)
	}
	return workspaces, nil
}

// UserWorkspace is a workspace the session user is a member of, with
// the role they hold in it. Used by the workspace picker on the
// dashboard sidebar.
type UserWorkspace struct {
	ID   uuid.UUID
	Name string
	Role string
}

// ListUserWorkspaces returns every workspace the given user is a
// member of, ordered by name. The join on workspace_members is what
// enforces the isolation: a user who is not a member of a workspace
// does not see it in this list, and cannot select it.
func (s *PostgresStore) ListUserWorkspaces(ctx context.Context, userID uuid.UUID) ([]UserWorkspace, error) {
	rows, err := s.pool.Query(ctx, `
		SELECT w.id, w.name, wm.role
		  FROM workspaces w
		  JOIN workspace_members wm ON wm.workspace_id = w.id
		 WHERE wm.user_id = $1
		 ORDER BY w.name ASC
	`, userID)
	if err != nil {
		return nil, fmt.Errorf("list user workspaces: %w", err)
	}
	defer rows.Close()

	var out []UserWorkspace
	for rows.Next() {
		var uw UserWorkspace
		if err := rows.Scan(&uw.ID, &uw.Name, &uw.Role); err != nil {
			continue
		}
		out = append(out, uw)
	}
	return out, rows.Err()
}

// AddRepository adds a repository to a workspace.
func (s *PostgresStore) AddRepository(
	ctx context.Context,
	workspaceID uuid.UUID,
	provider, url, defaultBranch, language, modulePath string,
) (*Repository, error) {
	tenantID, err := s.getTenantIDFromWorkspace(ctx, workspaceID)
	if err != nil {
		return nil, fmt.Errorf("failed to get tenant: %w", err)
	}

	repoName := modulePath
	if repoName == "" || repoName == "." {
		repoName = filepath.Base(url)
	}
	if repoName == "." || repoName == "/" || repoName == "" {
		repoName = "primary"
	}

	id := uuid.New()
	_, err = s.pool.Exec(ctx, `
		INSERT INTO repositories (
			id, tenant_id, workspace_id, name, provider, url, default_branch, language, module_path,
			enabled, analysis_status, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, true, 'pending', NOW(), NOW())
		ON CONFLICT (workspace_id, url) DO UPDATE
		SET tenant_id = EXCLUDED.tenant_id,
		    name = EXCLUDED.name,
		    provider = EXCLUDED.provider,
		    default_branch = EXCLUDED.default_branch,
		    language = EXCLUDED.language,
		    module_path = EXCLUDED.module_path,
		    updated_at = NOW()
	`, id, tenantID, workspaceID, repoName, provider, url, defaultBranch, language, modulePath)
	if err != nil {
		return nil, fmt.Errorf("failed to add repository: %w", err)
	}

	return &Repository{
		ID:             id,
		WorkspaceID:    workspaceID,
		Provider:       provider,
		URL:            url,
		DefaultBranch:  defaultBranch,
		Language:       language,
		ModulePath:     modulePath,
		Enabled:        true,
		AnalysisStatus: "pending",
		CurrentCommit:  nil,
		LastAnalyzedAt: nil,
		CreatedAt:      time.Now().UTC(),
		UpdatedAt:      time.Now().UTC(),
	}, nil
}

// ListRepositories lists all repositories in a workspace.
func (s *PostgresStore) ListRepositories(ctx context.Context, workspaceID uuid.UUID) ([]*Repository, error) {
	var repos []*Repository
	query := `
		SELECT id, workspace_id, provider, url, default_branch, language,
		       current_commit, enabled, analysis_status, last_analyzed_at,
		       created_at, updated_at
		FROM repositories
		WHERE workspace_id = $1
		ORDER BY created_at DESC
	`
	rows, err := s.pool.Query(ctx, query, workspaceID)
	if err != nil {
		return nil, fmt.Errorf("failed to list repositories: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var repo Repository
		var currentCommit *string
		err := rows.Scan(
			&repo.ID, &repo.WorkspaceID, &repo.Provider, &repo.URL, &repo.DefaultBranch,
			&repo.Language, &currentCommit, &repo.Enabled, &repo.AnalysisStatus,
			&repo.LastAnalyzedAt, &repo.CreatedAt, &repo.UpdatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan repository: %w", err)
		}
		repo.CurrentCommit = currentCommit
		repos = append(repos, &repo)
	}
	return repos, nil
}

// UpdateRepositorySyncStatus updates the sync status and commit SHA of a repository.
func (s *PostgresStore) UpdateRepositorySyncStatus(ctx context.Context, tenantIDStr string, repoID uuid.UUID, commitSHA, status string) error {
	if _, err := uuid.Parse(tenantIDStr); err != nil {
		return fmt.Errorf("invalid tenant ID: %w", err)
	}
	_, err := s.pool.Exec(ctx, `
		UPDATE repositories
		SET current_commit = $1, analysis_status = $2, last_analyzed_at = NOW()
		WHERE id = $3
	`, commitSHA, status, repoID)
	if err != nil {
		return fmt.Errorf("failed to update repository sync status: %w", err)
	}
	return nil
}

// UpdateRepositoryModulePath updates the module path of a repository.
func (s *PostgresStore) UpdateRepositoryModulePath(ctx context.Context, repoID uuid.UUID, modulePath string) error {
	_, err := s.pool.Exec(ctx, `
		UPDATE repositories SET module_path = $1 WHERE id = $2
	`, modulePath, repoID)
	if err != nil {
		return fmt.Errorf("failed to update module path: %w", err)
	}
	return nil
}

// SyncWorkspace executes a sync function for each repository in a workspace.
func (s *PostgresStore) SyncWorkspace(ctx context.Context, workspaceID uuid.UUID, syncFunc func(repo *Repository, path string) error) error {
	repos, err := s.ListRepositories(ctx, workspaceID)
	if err != nil {
		return fmt.Errorf("failed to list repositories: %w", err)
	}
	for _, repo := range repos {
		if !repo.Enabled {
			continue
		}
		tempDir := filepath.Join(os.TempDir(), "garuda-sync", workspaceID.String(), repo.ID.String())
		if err := os.MkdirAll(tempDir, 0755); err != nil {
			return fmt.Errorf("failed to create temp dir: %w", err)
		}
		if err := syncFunc(repo, tempDir); err != nil {
			continue
		}
	}
	return nil
}

// GetWorkspaceByName retrieves a workspace by name
func (s *PostgresStore) GetWorkspaceByName(ctx context.Context, tenantIDStr, name string) (*Workspace, error) {
	tenantID, err := uuid.Parse(tenantIDStr)
	if err != nil {
		return nil, err
	}
	var w Workspace
	err = s.pool.QueryRow(ctx, `SELECT id, tenant_id, name, root_path, is_go_work, description, created_at, updated_at FROM workspaces WHERE tenant_id = $1 AND name = $2`, tenantID, name).Scan(
		&w.ID, &w.TenantID, &w.Name, &w.RootPath, &w.IsGoWork, &w.Description, &w.CreatedAt, &w.UpdatedAt)
	if err != nil {
		return nil, err
	}
	return &w, nil
}

// DeleteWorkspaceByName deletes a workspace and cascades to repositories
func (s *PostgresStore) DeleteWorkspaceByName(ctx context.Context, tenantIDStr, name string) error {
	tenantID, err := uuid.Parse(tenantIDStr)
	if err != nil {
		return err
	}
	res, err := s.pool.Exec(ctx, `DELETE FROM workspaces WHERE tenant_id = $1 AND name = $2`, tenantID, name)
	if err != nil {
		return err
	}
	if res.RowsAffected() == 0 {
		return fmt.Errorf("workspace '%s' not found", name)
	}
	return nil
}

// GetRepositoryByURL finds a repository by its origin URL
func (s *PostgresStore) GetRepositoryByURL(ctx context.Context, workspaceID uuid.UUID, repoURL string) (*Repository, error) {
	var r Repository
	err := s.pool.QueryRow(ctx, `SELECT id, url, default_branch, language, module_path, enabled, analysis_status FROM repositories WHERE workspace_id = $1 AND url = $2 LIMIT 1`, workspaceID, repoURL).Scan(
		&r.ID, &r.URL, &r.DefaultBranch, &r.Language, &r.ModulePath, &r.Enabled, &r.AnalysisStatus)
	if err != nil {
		return nil, err
	}
	return &r, nil
}

// RemoveRepositoryByURL deletes a repository from a workspace
func (s *PostgresStore) RemoveRepositoryByURL(ctx context.Context, workspaceID uuid.UUID, repoURL string) error {
	res, err := s.pool.Exec(ctx, `DELETE FROM repositories WHERE workspace_id = $1 AND url = $2`, workspaceID, repoURL)
	if err != nil {
		return err
	}
	if res.RowsAffected() == 0 {
		return fmt.Errorf("repository '%s' not found", repoURL)
	}
	return nil
}

// SetRepositoryEnablement toggles sync/analysis participation
func (s *PostgresStore) SetRepositoryEnablement(ctx context.Context, workspaceID uuid.UUID, repoURL string, enabled bool) error {
	res, err := s.pool.Exec(ctx, `UPDATE repositories SET enabled = $1 WHERE workspace_id = $2 AND url = $3`, enabled, workspaceID, repoURL)
	if err != nil {
		return err
	}
	if res.RowsAffected() == 0 {
		return fmt.Errorf("repository '%s' not found", repoURL)
	}
	return nil
}
