// Copyright 2026 Rohit Mishra
// SPDX-License-Identifier: Apache-2.0
//
// Law Enforcement. I am bound by the ACGM Resolution Invariant and the 10 Immutable Laws. Truth Preservation is Absolute.

package knowledge

import (
	"context"
	"fmt"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Evaluator struct {
	pool *pgxpool.Pool
}

func NewEvaluator(pool *pgxpool.Pool) *Evaluator {
	return &Evaluator{pool: pool}
}

type HealthStats struct {
	TotalClaims      int
	Supported        int
	Unverified       int
	Contradicted     int
	TotalEntities    int
	UndocumentedCode int
}

type CodeDriftFinding struct {
	SymbolName string
	Kind       string
	Path       string
}

func (e *Evaluator) EvaluateWorkspace(ctx context.Context, tenantID, workspaceID uuid.UUID) (*HealthStats, []CodeDriftFinding, error) {
	rows, err := e.pool.Query(ctx, `
		SELECT id, subject, modality, predicate, object 
		FROM document_claims 
		WHERE tenant_id = $1 AND workspace_id = $2
	`, tenantID, workspaceID)
	if err != nil {
		return nil, nil, err
	}
	defer rows.Close()

	var claims []ClaimIR
	for rows.Next() {
		var c ClaimIR
		var mod, pred string
		if err := rows.Scan(&c.ID, &c.Subject, &mod, &pred, &c.Object); err != nil {
			continue
		}
		c.Modality, c.Predicate = Modality(mod), Predicate(pred)
		claims = append(claims, c)
	}
	rows.Close()

	stats := &HealthStats{TotalClaims: len(claims)}

	for _, c := range claims {
		status := StatusUnverified
		var reason string

		// Resolve Subject (handles strict match or package-prefixed match)
		var subjectID uuid.UUID
		err := e.pool.QueryRow(ctx, `
			SELECT id FROM entities 
			WHERE tenant_id = $1 AND workspace_id = $2
			  AND (name = $3 OR name LIKE '%.' || $3)
			LIMIT 1
		`, tenantID, workspaceID, c.Subject).Scan(&subjectID)

		if err != nil {
			status = StatusUnverified
			reason = fmt.Sprintf("DOC->CODE DRIFT: Subject '%s' not found in codebase AST", c.Subject)
			stats.Unverified++
			e.updateClaim(ctx, c.ID, nil, status, reason)
			continue
		}

		// Resolve Object
		var objectID uuid.UUID
		err = e.pool.QueryRow(ctx, `
			SELECT id FROM entities 
			WHERE tenant_id = $1 AND workspace_id = $2
			  AND (name = $3 OR name LIKE '%.' || $3)
			LIMIT 1
		`, tenantID, workspaceID, c.Object).Scan(&objectID)

		if err != nil && c.Predicate != PredicateIdempotent {
			status = StatusUnverified
			reason = fmt.Sprintf("DOC->CODE DRIFT: Target '%s' not found in codebase AST", c.Object)
			stats.Unverified++
			e.updateClaim(ctx, c.ID, &subjectID, status, reason)
			continue
		}

		// Evaluate Structural AST Relationships
		if c.Predicate == PredicateCalls {
			// The relationships table has never been written to. The
			// analyzer persists every edge into claims instead, where
			// claim_type carries the edge kind. Verified 2026-09-15:
			// relationships has 0 rows and no writer in the codebase;
			// claims has 11,469 CALLS edges in this workspace. Every
			// other reader in the codebase already queries claims.
			var exists bool
			_ = e.pool.QueryRow(ctx, `
				SELECT EXISTS(
					SELECT 1 FROM claims
					 WHERE workspace_id = $1
					   AND from_entity_id = $2
					   AND to_entity_id = $3
					   AND claim_type = 'CALLS'
				)
			`, workspaceID, subjectID, objectID).Scan(&exists)

			if c.Modality == ModalityMust {
				if exists {
					status = StatusSupported
					reason = "Verified: AST call relationship satisfied"
					stats.Supported++
				} else {
					status = StatusUnverified
					reason = "DOC->CODE DRIFT: Required call relationship not found in AST"
					stats.Unverified++
				}
			} else if c.Modality == ModalityMustNot {
				if exists {
					status = StatusContradicted
					reason = "ARCHITECTURE CONTRADICTION: Forbidden call relationship found in AST"
					stats.Contradicted++
				} else {
					status = StatusSupported
					reason = "Verified: Forbidden call is absent from AST"
					stats.Supported++
				}
			}
		} else {
			status = StatusUnverified
			reason = "Pending Runtime Telemetry / Invariant Validation"
			stats.Unverified++
		}

		e.updateClaim(ctx, c.ID, &subjectID, status, reason)
	}

	// Evaluate CODE -> DOC drift.
	//
	// The entities filter is workspace-scoped. Without e.workspace_id = $2
	// the query returns entities from every workspace the tenant owns.
	// Verified 2026-09-15: running `garuda docs verify` on
	// go-validation-10 listed chi entities whose file paths live under
	// /home/rohit/garuda-validation/. The chi repository is bound to the
	// garuda-validation workspace, not to go-validation-10. The JOIN's
	// dc.workspace_id = $2 filter did not help because the outer query
	// already included entities from other workspaces. This violates
	// invariant I-11 (tenant/workspace scope applied before traversal).
	codeRows, err := e.pool.Query(ctx, `
		SELECT e.name, e.kind, e.file_path
		FROM entities e
		LEFT JOIN document_claims dc 
		  ON (e.name = dc.subject OR e.name LIKE '%.' || dc.subject) 
		  AND dc.tenant_id = e.tenant_id
		  AND dc.workspace_id = $2
		WHERE e.tenant_id = $1 
		  AND e.workspace_id = $2
		  AND e.is_exported = true
		  AND e.kind IN ('function', 'method', 'struct')
		  AND dc.id IS NULL
		ORDER BY e.file_path, e.name ASC
		LIMIT 10
	`, tenantID, workspaceID)

	var undocumented []CodeDriftFinding
	if err == nil {
		defer codeRows.Close()
		for codeRows.Next() {
			var f CodeDriftFinding
			if err := codeRows.Scan(&f.SymbolName, &f.Kind, &f.Path); err == nil {
				undocumented = append(undocumented, f)
			}
		}
	}

	_ = e.pool.QueryRow(ctx, `SELECT COUNT(*) FROM entities WHERE tenant_id = $1 AND workspace_id = $2 AND is_exported = true`, tenantID, workspaceID).Scan(&stats.TotalEntities)
	stats.UndocumentedCode = len(undocumented)

	return stats, undocumented, nil
}

func (e *Evaluator) updateClaim(ctx context.Context, id uuid.UUID, entityID *uuid.UUID, status VerificationStatus, reason string) {
	_, _ = e.pool.Exec(ctx, `
		UPDATE document_claims 
		SET status = $1, contradiction_reason = $2, matched_entity_id = $3, updated_at = NOW() 
		WHERE id = $4
	`, string(status), reason, entityID, id)
}
