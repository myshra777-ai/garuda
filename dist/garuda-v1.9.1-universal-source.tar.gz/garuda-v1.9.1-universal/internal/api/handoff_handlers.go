// Copyright 2026 Rohit Mishra
// SPDX-License-Identifier: Apache-2.0
//
// Law Enforcement. I am bound by the ACGM Resolution Invariant and the 10 Immutable Laws. Truth Preservation is Absolute.

package api

import (
	"context"
	"encoding/json"
	"errors"
	"log/slog"
	"net/http"
	"time"

	"github.com/google/uuid"
	"github.com/gorilla/mux"
	"github.com/myshra777-ai/garuda/internal/store"
	"github.com/myshra777-ai/garuda/internal/telemetry"
	"github.com/myshra777-ai/garuda/internal/tenant"
	"github.com/myshra777-ai/garuda/internal/types"
)

// HandleHandoff processes POST /api/v1/agents/handoff.
func (s *Server) HandleHandoff(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	requestID := getRequestID(r)
	tenantID, ok := r.Context().Value(TenantIDKey).(uuid.UUID)
	if !ok {
		tenantID = tenant.CanonicalID
	}

	var req store.HandoffRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		s.RespondWithError(w, http.StatusBadRequest, "invalid json payload", requestID)
		return
	}
	if req.TaskID == uuid.Nil || req.SourceAgentID == uuid.Nil || req.TargetAgentID == uuid.Nil {
		s.RespondWithError(w, http.StatusUnprocessableEntity, "task_id, source_agent_id, and target_agent_id are required", requestID)
		return
	}
	req.TenantID = tenantID
	modelName, modelProvider := getModelInfo(r)
	ps, ok := s.store.(interface {
		ExecuteHandoffTransaction(context.Context, *store.HandoffRequest) (*store.HandoffResponse, error)
	})
	if !ok {
		telemetry.RecordHandoffWithModel(modelName, modelProvider, float64(time.Since(start).Milliseconds()), false)
		s.RespondWithError(w, http.StatusNotImplemented, "store does not support handoff operations", requestID)
		return
	}
	resp, err := ps.ExecuteHandoffTransaction(r.Context(), &req)
	if err != nil {
		telemetry.RecordHandoffWithModel(modelName, modelProvider, float64(time.Since(start).Milliseconds()), false)
		slog.Error("handoff execution failed", "error", err, "request_id", requestID, "task_id", req.TaskID, "tenant_id", tenantID)
		// Precondition failures are actionable — the caller can change
		// the target, fix the arguments, or retry. Surface the store's
		// message. Everything else stays collapsed: the wrapped errors
		// carry Postgres table and constraint names that should not
		// cross the API boundary.
		msg := "handoff execution failed"
		switch {
		case errors.Is(err, store.ErrSourceTransitioning),
			errors.Is(err, store.ErrTargetOffline),
			errors.Is(err, store.ErrSourceDoesNotOwn):
			msg = err.Error()
		}
		s.RespondWithError(w, http.StatusConflict, msg, requestID)
		return
	}
	telemetry.RecordHandoffWithModel(modelName, modelProvider, float64(time.Since(start).Milliseconds()), true)
	if s.sseBroker != nil {
		s.sseBroker.Publish(telemetry.EventType("agent_handoff"), map[string]interface{}{
			"handoff_id": resp.HandoffID, "checkpoint_id": resp.CheckpointID, "task_id": resp.TaskID,
			"source_agent_id": req.SourceAgentID, "target_agent_id": req.TargetAgentID,
			"reason": req.Reason, "status": resp.Status, "request_id": requestID,
		})
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(resp)
}

// HandleResume processes POST /api/v1/agents/resume.
func (s *Server) HandleResume(w http.ResponseWriter, r *http.Request) {
	requestID := getRequestID(r)
	tenantID, ok := r.Context().Value(TenantIDKey).(uuid.UUID)
	if !ok {
		tenantID = tenant.CanonicalID
	}
	var req struct {
		AgentID      uuid.UUID `json:"agent_id"`
		CheckpointID uuid.UUID `json:"checkpoint_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		s.RespondWithError(w, http.StatusBadRequest, "invalid json payload", requestID)
		return
	}
	if req.AgentID == uuid.Nil || req.CheckpointID == uuid.Nil {
		s.RespondWithError(w, http.StatusUnprocessableEntity, "agent_id and checkpoint_id are required", requestID)
		return
	}
	rs, ok := s.store.(interface {
		ResumeAgent(context.Context, uuid.UUID, uuid.UUID, uuid.UUID) (interface{}, error)
	})
	if !ok {
		s.RespondWithError(w, http.StatusNotImplemented, "store does not support resume operations", requestID)
		return
	}
	restoredState, err := rs.ResumeAgent(r.Context(), tenantID, req.AgentID, req.CheckpointID)
	if err != nil {
		slog.Error("resume agent failed", "error", err, "request_id", requestID, "agent_id", req.AgentID, "checkpoint_id", req.CheckpointID)
		s.RespondWithError(w, http.StatusNotFound, "failed to resume agent execution state", requestID)
		return
	}
	if s.sseBroker != nil {
		s.sseBroker.Publish(telemetry.EventType("agent_resumed"), map[string]interface{}{
			"agent_id": req.AgentID, "checkpoint_id": req.CheckpointID, "status": "working", "request_id": requestID,
		})
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(map[string]interface{}{
		"agent_id": req.AgentID, "checkpoint_id": req.CheckpointID, "status": "working", "state": restoredState, "request_id": requestID,
	})
}

// HandleGetLineage processes GET /api/v1/tasks/{task_id}/lineage.
func (s *Server) HandleGetLineage(w http.ResponseWriter, r *http.Request) {
	requestID := getRequestID(r)
	tenantID, ok := r.Context().Value(TenantIDKey).(uuid.UUID)
	if !ok {
		tenantID = tenant.CanonicalID
	}
	taskID, err := uuid.Parse(mux.Vars(r)["task_id"])
	if err != nil {
		s.RespondWithError(w, http.StatusBadRequest, "invalid task_id UUID", requestID)
		return
	}
	ls, ok := s.store.(interface {
		GetLineageDAG(context.Context, uuid.UUID, uuid.UUID) ([]types.LineageEdge, error)
	})
	if !ok {
		s.RespondWithError(w, http.StatusNotImplemented, "store does not support lineage queries", requestID)
		return
	}
	edges, err := ls.GetLineageDAG(r.Context(), tenantID, taskID)
	if err != nil {
		slog.Error("failed to query lineage DAG", "error", err, "request_id", requestID, "task_id", taskID, "tenant_id", tenantID)
		s.RespondWithError(w, http.StatusInternalServerError, "failed to query lineage DAG", requestID)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(map[string]interface{}{
		"task_id": taskID, "edges": edges, "total": len(edges), "request_id": requestID,
	})
}
