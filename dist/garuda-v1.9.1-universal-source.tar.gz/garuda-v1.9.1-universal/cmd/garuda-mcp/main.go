// Copyright 2026 Rohit Mishra
// SPDX-License-Identifier: Apache-2.0
//
// Law Enforcement. I am bound by the ACGM Resolution Invariant and the 10 Immutable Laws. Truth Preservation is Absolute.

package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"os"
	"os/signal"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/google/uuid"
	"github.com/myshra777-ai/garuda/internal/auth"
	"github.com/myshra777-ai/garuda/internal/budget"
	"github.com/myshra777-ai/garuda/internal/config"
	"github.com/myshra777-ai/garuda/internal/engine"
	"github.com/myshra777-ai/garuda/internal/store"
	"github.com/myshra777-ai/garuda/internal/tenant"
	"github.com/myshra777-ai/garuda/internal/types"
)

// MCPServer holds the process-scoped state of one MCP session.
//
// A session begins when the host (Claude Desktop, Cursor, or any
// other MCP client) spawns this process and ends when the process
// exits. The session ID is generated once at startup and is included
// in every log line and, in future commits, in every telemetry event.
//
// Store, engines, and auth service are all constructed once. The
// stdio loop can handle hundreds of tool calls without reconnecting
// to the database.
type MCPServer struct {
	store               *store.PostgresStore
	lineageEngine       *engine.LineageEngine
	contradictionEngine *engine.ContradictionEngine
	authService         *auth.AuthService
	jwtConfig           *auth.JWTConfig

	// sessionID is generated at startup and does not change for the
	// lifetime of the process.
	sessionID string
	startedAt time.Time

	// instanceHash is a stable identifier for this deployment
	// (hostname + cwd + salt). Used to correlate telemetry rows.
	instanceHash string
	// clientName is the clientInfo.name reported by the MCP client
	// during the initialize handshake. Used by garuda.briefing to key
	// the agent watermark so the same client resumes its own session
	// across restarts. Empty until initialize completes.
	clientName  string
	sessionDBID uuid.UUID
	sessionMu   sync.RWMutex
	oriented    bool
}

func main() {
	// Suppress the JWT banner and any other informational output.
	// stderr is transport in the MCP protocol; some clients treat
	// every line from the child process as an MCP frame regardless
	// of which stream it arrived on. Set the flag before any
	// package that might write to stderr.
	_ = os.Setenv("GARUDA_MCP_QUIET", "1")
	// stdout is the JSON-RPC channel and must contain nothing but
	// line-delimited MCP messages.
	//
	// stderr is also constrained in the MCP transport: some clients
	// (notably Cursor 3.17.x via its "Shared MCP process") treat every
	// line from the child process as an MCP frame, regardless of which
	// stream it arrived on. A startup banner or an INFO log on stderr
	// is therefore parsed as protocol and rejected. The MCP process
	// runs silent by default; set GARUDA_MCP_DEBUG=1 to keep stderr
	// for interactive debugging.
	if os.Getenv("GARUDA_MCP_DEBUG") == "" {
		slog.SetDefault(slog.New(slog.NewTextHandler(io.Discard, nil)))
	}

	enc := json.NewEncoder(os.Stdout)

	// DATABASE_URL is required. There is no fallback: a missing value
	// in production should fail loudly, not connect to a local test
	// database.
	config.LoadDotEnv()
	dbURL := os.Getenv("DATABASE_URL")
	if dbURL == "" && os.Getenv("GARUDA_ENV") != "production" {
		dbURL = config.ResolveDBURL()
	}
	if dbURL == "" {
		_ = enc.Encode(MCPResponse{
			JSONRPC: "2.0",
			Error: &MCPError{
				Code:    -32000,
				Message: "DATABASE_URL environment variable is required",
			},
		})
		slog.Error("DATABASE_URL is not set")
		os.Exit(1)
	}

	dbStore, err := store.NewPostgresStore(dbURL)
	if err != nil {
		_ = enc.Encode(MCPResponse{
			JSONRPC: "2.0",
			Error: &MCPError{
				Code:    -32000,
				Message: fmt.Sprintf("database connection failed: %v", err),
			},
		})
		slog.Error("Failed to connect to database", "error", err)
		os.Exit(1)
	}
	defer dbStore.Close()

	jwtConfig, _ := auth.NewJWTConfig("garuda-mcp", "garuda-api", 15*time.Minute)
	authService := auth.NewAuthService(dbStore, jwtConfig)
	lineageEngine := engine.NewLineageEngine(dbStore)
	contradictionEngine := engine.NewContradictionEngine(dbStore)

	server := &MCPServer{
		store:               dbStore,
		lineageEngine:       lineageEngine,
		contradictionEngine: contradictionEngine,
		authService:         authService,
		jwtConfig:           jwtConfig,
		sessionID:           uuid.New().String(),
		startedAt:           time.Now().UTC(),
		instanceHash:        computeInstanceHash(),
	}

	slog.Info("Garuda MCP Server ready",
		"session_id", server.sessionID,
		"pid", os.Getpid(),
	)

	// Graceful shutdown on SIGINT/SIGTERM.
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sigChan
		slog.Info("Received shutdown signal", "session_id", server.sessionID)
		server.closeSession(context.Background(), "graceful")
		os.Exit(0)
	}()

	// Line-delimited JSON-RPC over stdio. The loop handles one request
	// at a time and exits when stdin closes (EOF), which the MCP host
	// signals by closing the pipe.
	//
	// A parse error does not terminate the process. The host may send
	// another well-formed request; we respond with a JSON-RPC parse
	// error and continue reading.
	dec := json.NewDecoder(os.Stdin)
	requestCount := 0

	for {
		var req MCPRequest
		if err := dec.Decode(&req); err != nil {
			if err == io.EOF {
				slog.Info("stdin closed, shutting down",
					"session_id", server.sessionID,
					"requests_handled", requestCount,
				)
				server.closeSession(context.Background(), "graceful")
				return
			}
			// Malformed input. Respond with a parse error and keep the
			// loop alive; the host may recover.
			slog.Warn("Failed to parse MCP request",
				"session_id", server.sessionID,
				"error", err,
			)
			_ = enc.Encode(MCPResponse{
				JSONRPC: "2.0",
				ID:      nil,
				Error: &MCPError{
					Code:    -32700,
					Message: fmt.Sprintf("Parse error: %v", err),
				},
			})
			continue
		}

		requestCount++

		// JSON-RPC 2.0: a message with no "id" is a notification and
		// MUST NOT receive a response. The MCP spec uses notifications
		// for lifecycle events such as notifications/initialized, which
		// every client sends after initialize completes. Responding to
		// one produces a frame with "id": null, which Cursor's MCP SDK
		// rejects against its strict zod union and tears the transport
		// down.
		//
		// Notifications are silently dropped. This is the same class of
		// fix every MCP server that has hit this bug applies.
		if req.ID == nil {
			continue
		}

		resp := server.handleRequest(req)

		if err := enc.Encode(resp); err != nil {
			slog.Error("Failed to write MCP response",
				"session_id", server.sessionID,
				"error", err,
			)
			return
		}
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// MCP JSON-RPC types
// ─────────────────────────────────────────────────────────────────────────────

type MCPRequest struct {
	JSONRPC string                 `json:"jsonrpc"`
	ID      interface{}            `json:"id"`
	Method  string                 `json:"method"`
	Params  map[string]interface{} `json:"params,omitempty"`
}

type MCPResponse struct {
	JSONRPC string      `json:"jsonrpc"`
	ID      interface{} `json:"id"`
	Result  interface{} `json:"result,omitempty"`
	Error   *MCPError   `json:"error,omitempty"`
}

type MCPError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

// ─────────────────────────────────────────────────────────────────────────────
// Tool registry
// ─────────────────────────────────────────────────────────────────────────────

// allTools is the canonical list of every tool this server exposes.
// handleToolsList returns it verbatim; toolNames is derived from it.
// The write path and any future policy surface iterate this slice
// rather than maintaining a parallel list that can drift.
var allTools = []map[string]interface{}{
	{
		"name":        "garuda.briefing",
		"description": "Session-start briefing: workspace state, trust anchor, scale, top hubs, active policies, open contradictions, and what changed since this agent's last briefing. Read-only. Call this first.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{
					"type":        "string",
					"description": "Workspace name. Defaults to the server's active workspace.",
				},
				"agent_id": map[string]interface{}{
					"type":        "string",
					"description": "Caller-supplied agent identifier. Defaults to the MCP client name from the handshake.",
				},
			},
		},
	},
	{
		"name":        "garuda.query",
		"description": "Query the Garuda knowledge graph with natural language",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"query":     map[string]interface{}{"type": "string", "description": "The natural language query"},
				"tenant_id": map[string]interface{}{"type": "string", "description": "Optional tenant ID"},
			},
			"required": []string{"query"},
		},
	},
	{
		"name":        "garuda.get_lineage",
		"description": "Get the full lineage of a decision",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"decision_id": map[string]interface{}{"type": "string", "description": "The decision UUID"},
				"tenant_id":   map[string]interface{}{"type": "string", "description": "Tenant ID"},
			},
			"required": []string{"decision_id"},
		},
	},
	{
		"name":        "garuda.detect_contradictions",
		"description": "Detect unresolved contradictions in the tenant knowledge graph",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant ID"},
				"scope":     map[string]interface{}{"type": "string", "description": "Optional scope filter"},
			},
		},
	},
	{
		"name":        "garuda.get_impact",
		"description": "Find what breaks if a decision is changed",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"decision_id": map[string]interface{}{"type": "string", "description": "The decision UUID"},
				"tenant_id":   map[string]interface{}{"type": "string", "description": "Tenant ID"},
			},
			"required": []string{"decision_id"},
		},
	},
	{
		"name":        "garuda.blast_radius",
		"description": "Compute the blast radius of a symbol change: which entities consume the target entity, directly or transitively, up to a depth. Read-only. Returns a critical-first list and per-severity counts.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id":      map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace":      map[string]interface{}{"type": "string", "description": "Workspace name"},
				"entity_id":      map[string]interface{}{"type": "string", "description": "Target entity UUID"},
				"depth":          map[string]interface{}{"type": "integer", "description": "Max traversal depth. Default 3."},
				"min_confidence": map[string]interface{}{"type": "number", "description": "Minimum edge confidence. Default 0.50."},
			},
			"required": []string{"entity_id"},
		},
	},
	{
		"name":        "garuda.propose_decision",
		"description": "Propose a new decision (creates a draft)",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"title":        map[string]interface{}{"type": "string", "description": "Decision title"},
				"scope_domain": map[string]interface{}{"type": "string", "description": "Scope domain"},
				"scope_system": map[string]interface{}{"type": "string", "description": "Scope system"},
				"tenant_id":    map[string]interface{}{"type": "string", "description": "Tenant ID"},
			},
			"required": []string{"title"},
		},
	},
	// ── Governance tools (Phase 2.2a) ──
	{
		"name":        "garuda.policy.list",
		"description": "List policies registered for a tenant. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID; falls back to GARUDA_TENANT_ID env or default tenant"},
			},
		},
	},
	{
		"name":        "garuda.governance.status",
		"description": "Aggregate governance state: active policies, documentation health, contradiction count. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name; falls back to GARUDA_WORKSPACE env or 'default'"},
			},
		},
	},
	{
		"name":        "garuda.check_drift",
		"description": "Documentation-to-code drift report. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
			},
		},
	},
	{
		"name":        "garuda.query_claims",
		"description": "Query document claims matching a subject. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"subject":   map[string]interface{}{"type": "string", "description": "Filter by subject or object (substring)"},
			},
		},
	},
	// ── Policy + semantic tools (Phase 2.2b/2.2c) ──
	{
		"name":        "garuda.policy.evaluate",
		"description": "Dry-run the policy engine against a workspace and return the decisions it would make. Does NOT persist or Merkle-anchor. Use 'garuda policy evaluate' from the CLI to anchor a real governance decision.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id":    map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace":    map[string]interface{}{"type": "string", "description": "Workspace name"},
				"policy_dir":   map[string]interface{}{"type": "string", "description": "Directory containing policy YAML. Defaults to GARUDA_POLICY_DIR or ./policies"},
				"subject_kind": map[string]interface{}{"type": "string", "description": "Optional subject kind"},
				"subject_id":   map[string]interface{}{"type": "string", "description": "Optional subject ID"},
				"actor":        map[string]interface{}{"type": "string", "description": "Optional actor identifier"},
			},
		},
	},
	{
		"name":        "garuda.verify_policy_evaluation",
		"description": "Verify the Merkle inclusion proof for a persisted policy evaluation. Returns valid=true if the proof recomputes to the anchored root. Read-only; no side effects.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id":     map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"evaluation_id": map[string]interface{}{"type": "string", "description": "Policy evaluation UUID returned by garuda policy evaluate --save"},
			},
			"required": []string{"evaluation_id"},
		},
	},
	{
		"name":        "garuda.entities",
		"description": "List semantic entities in a workspace. Filterable by package and kind. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"package":   map[string]interface{}{"type": "string", "description": "Optional package name substring"},
				"kind":      map[string]interface{}{"type": "string", "description": "Optional entity kind (struct, interface, function, method)"},
				"limit":     map[string]interface{}{"type": "number", "description": "Max rows, default 100, cap 1000"},
			},
		},
	},
	{
		"name":        "garuda.inspect",
		"description": "Inspect one entity with its incoming and outgoing relationships. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"entity_id": map[string]interface{}{"type": "string", "description": "Entity UUID"},
			},
			"required": []string{"entity_id"},
		},
	},
	// ── Graph structure tools (Phase 1) ──
	{
		"name":        "garuda.subclasses",
		"description": "List entities that inherit from or embed the subject. Uses INHERITS and EMBEDS claims. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"entity_id": map[string]interface{}{"type": "string", "description": "Subject entity UUID"},
				"name":      map[string]interface{}{"type": "string", "description": "Subject entity name (alternative to entity_id)"},
				"language":  map[string]interface{}{"type": "string", "description": "Optional language filter (go, python, typescript)"},
				"limit":     map[string]interface{}{"type": "number", "description": "Max rows, default 50, cap 500"},
			},
		},
	},
	{
		"name":        "garuda.implementers",
		"description": "List entities that implement the subject interface. Uses IMPLEMENTS claims. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"entity_id": map[string]interface{}{"type": "string", "description": "Subject interface UUID"},
				"name":      map[string]interface{}{"type": "string", "description": "Subject interface name (alternative to entity_id)"},
				"limit":     map[string]interface{}{"type": "number", "description": "Max rows, default 50, cap 500"},
			},
		},
	},
	{
		"name":        "garuda.neighbors",
		"description": "List every entity connected to the subject in one hop, both directions. Resolves names, packages, kinds in one query. External stubs excluded by default. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id":        map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace":        map[string]interface{}{"type": "string", "description": "Workspace name"},
				"entity_id":        map[string]interface{}{"type": "string", "description": "Subject entity UUID"},
				"edge_kinds":       map[string]interface{}{"type": "array", "items": map[string]interface{}{"type": "string"}, "description": "Optional filter, e.g. [\"CALLS\",\"IMPORTS\"]"},
				"include_external": map[string]interface{}{"type": "boolean", "description": "Include external stubs (default false)"},
				"limit":            map[string]interface{}{"type": "number", "description": "Max rows, default 100, cap 500"},
			},
			"required": []string{"entity_id"},
		},
	},
	// ── State management tools (Phase 2.4) ──
	{
		"name":        "garuda.handoff",
		"description": "Initiate an atomic task handoff between two agents. Creates a checkpoint of the source agent's state, transfers task ownership, and transitions both agents' statuses. Wraps the same Serializable transaction the HTTP API uses. Caller must ensure source_agent_id currently owns task_id. Returns {status: \"completed\", handoff_id, checkpoint_id} on success, or {status: \"failed\", reason} on precondition failure.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id":       map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"task_id":         map[string]interface{}{"type": "string", "description": "Task UUID being handed off"},
				"source_agent_id": map[string]interface{}{"type": "string", "description": "Agent UUID currently owning the task"},
				"target_agent_id": map[string]interface{}{"type": "string", "description": "Agent UUID taking ownership"},
				"reason":          map[string]interface{}{"type": "string", "description": "Optional human-readable reason"},
				"checkpoint_data": map[string]interface{}{"type": "object", "description": "Optional serializable state to carry across the handoff"},
			},
			"required": []string{"task_id", "source_agent_id", "target_agent_id"},
		},
	},
	{
		"name":        "garuda.resume",
		"description": "Restore the state from an active checkpoint created by garuda.handoff, and mark the checkpoint as consumed. A second resume of the same checkpoint returns {status: \"not_found\"}. Wraps the same Serializable transaction the HTTP API uses.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id":     map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"agent_id":      map[string]interface{}{"type": "string", "description": "Agent UUID performing the resume"},
				"checkpoint_id": map[string]interface{}{"type": "string", "description": "Checkpoint UUID returned by garuda.handoff"},
			},
			"required": []string{"agent_id", "checkpoint_id"},
		},
	},
	{
		"name":        "garuda.find_entity",
		"description": "Find entities by name pattern, kind, package, or file path. Results ranked by inbound edge count so the most-connected matches appear first. Read-only.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id":          map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace":          map[string]interface{}{"type": "string", "description": "Workspace name"},
				"name_pattern":       map[string]interface{}{"type": "string", "description": "Regex against entity name"},
				"kind":               map[string]interface{}{"type": "string", "description": "Entity kind (struct, interface, function, method, class, package)"},
				"package":            map[string]interface{}{"type": "string", "description": "Package name substring"},
				"file_path_contains": map[string]interface{}{"type": "string", "description": "File path substring"},
				"exported_only":      map[string]interface{}{"type": "boolean", "description": "Only exported entities (default false)"},
				"limit":              map[string]interface{}{"type": "number", "description": "Max rows, default 50, cap 500"},
			},
		},
	},
	// ── Active Garuda Talon Harness tools (v1.5) ──
	{
		"name":        "garuda.talon_pre_edit",
		"description": "MANDATORY pre-edit check: call before modifying any file or symbol. Returns transitive blast radius, callers, applicable ADR MUST/MUST_NOT claims, and active policy guardrails.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"target":    map[string]interface{}{"type": "string", "description": "Target symbol name or file path about to be edited"},
			},
		},
	},
	{
		"name":        "garuda.talon_verify_edit",
		"description": "MANDATORY post-edit verification gate: call immediately after modifying code. Runs incremental AST sync, diff-scoped policy evaluation, and ADR verification, anchors the decision to the RFC 6962 Merkle ledger, and returns self-repair instructions if BLOCKED.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"tenant_id": map[string]interface{}{"type": "string", "description": "Tenant UUID"},
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"repo_dir":  map[string]interface{}{"type": "string", "description": "Repository root directory (default .)"},
				"staged":    map[string]interface{}{"type": "boolean", "description": "Check staged git index changes"},
				"diff":      map[string]interface{}{"type": "string", "description": "Git revision range to check"},
				"files":     map[string]interface{}{"type": "string", "description": "Comma-separated list of modified files"},
			},
		},
	},
	// ── v1.9.0 Human-in-the-Loop Weighted Logic, Criticality Tiers, Financial Audit & Auto-Rulebook tools ──
	{
		"name":        "garuda.disambiguate_logic",
		"description": "Compare competing undocumented formulas across teams (e.g. Loss Ratio across Ops, Marketing, Management) with 0.0-1.0 team weights, surface criticality tiers (HIGH_SEVERE, MEDIUM, LOW), and human-readable blast radius so the human developer takes the final call.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"team":      map[string]interface{}{"type": "string", "description": "Active team context (ops, marketing, management)"},
				"concept":   map[string]interface{}{"type": "string", "description": "Business concept or formula to disambiguate"},
			},
		},
	},
	{
		"name":        "garuda.audit_financial_discrepancy",
		"description": "Audit cross-team business and financial number discrepancies (e.g. 48 Crore vs 4.8 Crore Total Claims Paid) by tracing AST and SQL unit-scaling lineage before an external audit.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"metric":    map[string]interface{}{"type": "string", "description": "Financial or business metric to reconcile"},
			},
		},
	},
	{
		"name":        "garuda.synthesize_rulebook",
		"description": "Synthesize unorganized repository architecture, surface criticality tiers, and multi-team formula weights into a structured draft Base Rulebook for human stakeholder review and approval.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
			},
		},
	},
	{
		"name":        "garuda.decide_logic_variant",
		"description": "Record a human stakeholder decision (APPROVE_VARIANT, FREEZE_SEVERE, or SET_CUSTOM_WEIGHT) on a competing multi-team formula variant in PostgreSQL.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace":       map[string]interface{}{"type": "string", "description": "Workspace name"},
				"team":            map[string]interface{}{"type": "string", "description": "Active team role (ops, marketing, management)"},
				"variant_id":      map[string]interface{}{"type": "string", "description": "Variant ID (e.g. loss_ratio_ops_v1)"},
				"decision_action": map[string]interface{}{"type": "string", "description": "APPROVE_VARIANT or FREEZE_SEVERE"},
				"custom_weight":   map[string]interface{}{"type": "number", "description": "Optional custom weight (0.0 to 1.0)"},
			},
		},
	},
	{
		"name":        "garuda.reconcile_financial_audit",
		"description": "Approve and reconcile a flagged cross-team financial discrepancy (e.g. 48 Crore vs 4.8 Crore Claims Paid) in the audit ledger.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace":   map[string]interface{}{"type": "string", "description": "Workspace name"},
				"audit_id":    map[string]interface{}{"type": "string", "description": "Financial audit item ID"},
				"approved_by": map[string]interface{}{"type": "string", "description": "Approving Finance Controller or Auditor"},
			},
		},
	},
	{
		"name":        "garuda.approve_base_rulebook",
		"description": "Approve and seal the synthesized draft Base Rulebook into .garuda/APPROVED_BASE_RULEBOOK.md with an RFC 6962 SHA-256 digest.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace":   map[string]interface{}{"type": "string", "description": "Workspace name"},
				"approved_by": map[string]interface{}{"type": "string", "description": "Approver name or role"},
			},
		},
	},
	{
		"name":        "garuda.criticality_tiers",
		"description": "List or register 3-Tier Surface Criticality classifications (HIGH_SEVERE freeze, MEDIUM trade-off, LOW UI box alignment).",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace":        map[string]interface{}{"type": "string", "description": "Workspace name"},
				"tier_filter":      map[string]interface{}{"type": "string", "description": "Optional filter: HIGH_SEVERE, MEDIUM, LOW, or ALL"},
				"surface_name":     map[string]interface{}{"type": "string", "description": "Optional custom surface name to register"},
				"package_pattern":  map[string]interface{}{"type": "string", "description": "Optional package pattern for custom surface"},
				"criticality_tier": map[string]interface{}{"type": "string", "description": "Optional tier for custom surface (HIGH_SEVERE, MEDIUM, LOW)"},
			},
		},
	},
	{
		"name":        "garuda.docs_graph",
		"description": "Retrieve the 4-Tier Document-to-Code & Guardrails Lineage Matrix (Documents -> Normative Rules -> Active Policies -> AST Symbols).",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"doc_type":  map[string]interface{}{"type": "string", "description": "Optional filter: ADR, SPEC, POLICY, or ALL"},
			},
		},
	},
	{
		"name":        "garuda.docs_ingest",
		"description": "Ingest Markdown ADRs or design specifications into document_claims and correlate them against workspace AST symbols.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"path":      map[string]interface{}{"type": "string", "description": "File or directory path to ingest (default docs/adr)"},
			},
		},
	},
	{
		"name":        "garuda.doctor_diagnose",
		"description": "Run the Garuda System Doctor diagnostic suite across platform, PostgreSQL, Talon contract, and API gateway health.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
			},
		},
	},
	{
		"name":        "garuda.build_matrix_check",
		"description": "Verify the codebase across the 4-target Cross-Platform Build Matrix (linux/amd64, darwin/arm64, windows/amd64, cgo/purego) and return the deterministic BuildContext receipt.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"repo_dir":  map[string]interface{}{"type": "string", "description": "Repository root path"},
			},
		},
	},
	{
		"name":        "garuda.hygiene_report",
		"description": "Run the static code hygiene analyzer on the workspace graph to report advisory unreferenced candidates, duplicate symbol names, and stdlib alternatives.",
		"inputSchema": map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"workspace": map[string]interface{}{"type": "string", "description": "Workspace name"},
				"limit":     map[string]interface{}{"type": "number", "description": "Max findings per category (default 25)"},
			},
		},
	},
}

// toolNames is the derived whitelist of valid tool names. Built once
// from allTools so it cannot drift from the registry. Used by
// handleToolsCall to reject unknown tools before dispatch.
var toolNames = func() map[string]bool {
	m := make(map[string]bool, len(allTools))
	for _, t := range allTools {
		if name, ok := t["name"].(string); ok {
			m[name] = true
		}
	}
	return m
}()

// ─────────────────────────────────────────────────────────────────────────────
// Request dispatch
// ─────────────────────────────────────────────────────────────────────────────

func (s *MCPServer) handleRequest(req MCPRequest) MCPResponse {
	switch req.Method {
	case "initialize":
		return s.handleInitialize(req)
	case "tools/list":
		return s.handleToolsList(req)
	case "tools/call":
		return s.handleToolsCall(req)
	case "prompts/list":
		return s.handlePromptsList(req)
	case "prompts/get":
		return s.handlePromptsGet(req)
	case "resources/list":
		return s.handleResourcesList(req)
	case "resources/read":
		return s.handleResourcesRead(req)
	default:
		return s.errorResponse(req.ID, -32601, "Method not found: "+req.Method)
	}
}

func (s *MCPServer) handleInitialize(req MCPRequest) MCPResponse {
	// Capture clientInfo.name from the handshake. MCP clients send
	// params.clientInfo.name (e.g. "cursor", "claude-ai"). The briefing
	// uses it to key the per-agent watermark so a client resumes its
	// own session across restarts. If the field is absent, the
	// briefing falls back to "default".
	if req.Params != nil {
		if ci, ok := req.Params["clientInfo"].(map[string]interface{}); ok {
			if name, ok := ci["name"].(string); ok && name != "" {
				s.clientName = name
			}
		}
	}

	// Record session start. Best-effort — the handshake completes
	// regardless.
	clientVersion := ""
	if req.Params != nil {
		if ci, ok := req.Params["clientInfo"].(map[string]interface{}); ok {
			if v, ok := ci["version"].(string); ok {
				clientVersion = v
			}
		}
	}
	agentID := os.Getenv("GARUDA_AGENT")
	if agentID == "" {
		agentID = "mcp-agent"
	}
	s.recordSessionStart(context.Background(), s.clientName, clientVersion, agentID)

	return MCPResponse{
		JSONRPC: "2.0",
		ID:      req.ID,
		Result: map[string]interface{}{
			"protocolVersion": "2025-06-18",
			"capabilities": map[string]interface{}{
				"tools":     map[string]interface{}{},
				"prompts":   map[string]interface{}{},
				"resources": map[string]interface{}{},
			},
			"instructions": "Garuda Talon Active Enforcement is enabled. Call garuda.talon_pre_edit before modifying code and garuda.talon_verify_edit immediately after editing to verify 0 net-new policy or ADR violations.",
			"serverInfo": map[string]interface{}{
				"name":    "garuda-mcp",
				"version": "1.9.1",
			},
		},
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Tool listing
// ─────────────────────────────────────────────────────────────────────────────

func (s *MCPServer) handleToolsList(req MCPRequest) MCPResponse {
	return MCPResponse{
		JSONRPC: "2.0",
		ID:      req.ID,
		Result: map[string]interface{}{
			"tools": allTools,
		},
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Budget enforcement
// ─────────────────────────────────────────────────────────────────────────────

// checkAndConsumeBudget performs a pre-flight budget check and returns
// a commit closure. The caller invokes commit only after business
// logic has succeeded, so failed operations consume no tokens.
func (s *MCPServer) checkAndConsumeBudget(ctx context.Context, tenantID uuid.UUID, agentID, toolName string, payload interface{}) (func(), error) {
	budgetState, err := s.store.GetTenantBudget(ctx, tenantID)
	if err != nil {
		return nil, err
	}

	estimatedTokens := budget.EstimateTokens("mcp_"+toolName, payload)
	if budgetState.Status == "exhausted" || budgetState.TokenBalance < int64(estimatedTokens) {
		return nil, fmt.Errorf("insufficient budget: need %d, have %d", estimatedTokens, budgetState.TokenBalance)
	}

	commit := func() {
		req := types.BudgetConsumptionRequest{
			AgentID:        agentID,
			TokensUsed:     estimatedTokens,
			ExecutionsUsed: 1,
			Operation:      "mcp_" + toolName,
		}
		_, _ = s.store.ConsumeBudgetDeduct(ctx, tenantID, req)
	}

	return commit, nil
}

// ─────────────────────────────────────────────────────────────────────────────
// Tool dispatch
// ─────────────────────────────────────────────────────────────────────────────

func (s *MCPServer) handleToolsCall(req MCPRequest) MCPResponse {
	toolName, ok := req.Params["name"].(string)
	if !ok {
		return s.errorResponse(req.ID, -32602, "Invalid tool name")
	}

	// Whitelist check before dispatch. Reject unknown tools here so
	// the switch below only handles valid names; the default branch
	// stays as defense-in-depth if the whitelist and switch ever drift.
	if !toolNames[toolName] {
		return s.errorResponse(req.ID, -32601, "Tool not found: "+toolName)
	}

	args, _ := req.Params["arguments"].(map[string]interface{})

	agentID, _ := args["agent_id"].(string)
	if agentID == "" {
		agentID = "mcp-agent"
	}

	start := time.Now()
	var result interface{}
	var err error

	// Handlers control their own pre-flight and post-commit budget lifecycles.
	switch toolName {
	case "garuda.query":
		result, err = s.handleQuery(args)
	case "garuda.briefing":
		result, err = s.handleBriefing(args)
	case "garuda.get_lineage":
		result, err = s.handleGetLineage(args)
	case "garuda.detect_contradictions":
		result, err = s.handleDetectContradictions(args)
	case "garuda.get_impact":
		result, err = s.handleGetImpact(args)
	case "garuda.blast_radius":
		result, err = s.handleBlastRadius(args)
	case "garuda.propose_decision":
		result, err = s.handleProposeDecision(args)
	case "garuda.policy.list":
		result, err = s.handlePolicyList(args)
	case "garuda.governance.status":
		result, err = s.handleGovernanceStatus(args)
	case "garuda.check_drift":
		result, err = s.handleCheckDrift(args)
	case "garuda.query_claims":
		result, err = s.handleQueryClaims(args)
	case "garuda.policy.evaluate":
		result, err = s.handlePolicyEvaluate(args)
	case "garuda.verify_policy_evaluation":
		result, err = s.handleVerifyPolicyEvaluation(args)
	case "garuda.entities":
		result, err = s.handleEntities(args)
	case "garuda.inspect":
		result, err = s.handleInspect(args)
	case "garuda.subclasses":
		result, err = s.handleSubclasses(args)
	case "garuda.implementers":
		result, err = s.handleImplementers(args)
	case "garuda.neighbors":
		result, err = s.handleNeighbors(args)
	case "garuda.handoff":
		result, err = s.handleHandoff(args)
	case "garuda.resume":
		result, err = s.handleResume(args)
	case "garuda.find_entity":
		result, err = s.handleFindEntity(args)
	case "garuda.talon_pre_edit":
		result, err = s.handleTalonPreEdit(args)
	case "garuda.talon_verify_edit":
		result, err = s.handleTalonVerifyEdit(args)
	case "garuda.disambiguate_logic":
		result, err = s.handleDisambiguateLogic(args)
	case "garuda.audit_financial_discrepancy":
		result, err = s.handleAuditFinancialDiscrepancy(args)
	case "garuda.synthesize_rulebook":
		result, err = s.handleSynthesizeRulebook(args)
	case "garuda.decide_logic_variant":
		result, err = s.handleDecideLogicVariant(args)
	case "garuda.reconcile_financial_audit":
		result, err = s.handleReconcileFinancialAudit(args)
	case "garuda.approve_base_rulebook":
		result, err = s.handleApproveBaseRulebook(args)
	case "garuda.criticality_tiers":
		result, err = s.handleCriticalityTiers(args)
	case "garuda.docs_graph":
		result, err = s.handleDocsGraph(args)
	case "garuda.docs_ingest":
		result, err = s.handleDocsIngest(args)
	case "garuda.doctor_diagnose":
		result, err = s.handleDoctorDiagnose(args)
	case "garuda.build_matrix_check":
		result, err = s.handleBuildMatrixCheck(args)
	case "garuda.hygiene_report":
		result, err = s.handleHygieneReport(args)

	default:
		return s.errorResponse(req.ID, -32601, "Tool not found: "+toolName)
	}

	duration := time.Since(start)

	// Telemetry on both paths. Best-effort: a failure to record does
	// not affect the response, and is logged at warn level.
	//
	// tokensEstimated is 0 for read-only tools, positive for the
	// propose path. The exact value matters less than the fact that a
	// row is written with a truthful latency and outcome.
	s.emitToolInvocation(
		context.Background(),
		toolName,
		agentID,
		0, // tokensEstimated — the propose path tracks this via budget, not here
		duration,
		err == nil,
	)
	s.recordToolCall(context.Background(), toolName, duration, err, args)

	if err != nil {
		return s.errorResponse(req.ID, -32000, err.Error())
	}

	result = s.injectActiveContract(toolName, result)

	return MCPResponse{
		JSONRPC: "2.0",
		ID:      req.ID,
		Result: map[string]interface{}{
			"content": []map[string]interface{}{
				{
					"type": "text",
					"text": mustJSON(result),
				},
			},
		},
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Tool handlers
// ─────────────────────────────────────────────────────────────────────────────

func (s *MCPServer) handleProposeDecision(args map[string]interface{}) (interface{}, error) {
	tenantID, _ := s.resolveTenant(args)
	agentID, _ := args["agent_id"].(string)
	if agentID == "" {
		agentID = "mcp-agent"
	}

	commitBudget, err := s.checkAndConsumeBudget(context.Background(), tenantID, agentID, "propose_decision", args)
	if err != nil {
		return nil, err
	}

	result, err := s.processProposeDecisionLogic(args)
	if err != nil {
		return nil, err
	}

	commitBudget()

	return result, nil
}

func (s *MCPServer) processProposeDecisionLogic(args map[string]interface{}) (interface{}, error) {
	title, ok := args["title"].(string)
	if !ok || title == "" {
		return nil, fmt.Errorf("title is required")
	}
	scopeDomain, _ := args["scope_domain"].(string)
	scopeSystem, _ := args["scope_system"].(string)
	tenantID, _ := s.resolveTenant(args)

	if tenantID == uuid.Nil {
		tenantID = tenant.CanonicalID
	}

	now := time.Now().UTC()
	decision := &types.Decision{
		ID:         uuid.New(),
		TenantID:   tenantID,
		Title:      title,
		Status:     types.StatusDraft,
		Scope:      types.Scope{Domain: scopeDomain, System: scopeSystem},
		Owner:      "mcp-agent",
		Confidence: 0.8,
		CreatedAt:  now,
		UpdatedAt:  now,
	}

	if err := s.store.SaveDecision(context.Background(), decision); err != nil {
		return nil, err
	}

	return map[string]interface{}{
		"id":        decision.ID.String(),
		"tenant_id": decision.TenantID.String(),
		"title":     decision.Title,
		"status":    decision.Status.String(),
	}, nil
}

func (s *MCPServer) handleQuery(args map[string]interface{}) (interface{}, error) {
	tenantID, _ := s.resolveTenant(args)
	commitBudget, err := s.checkAndConsumeBudget(context.Background(), tenantID, "mcp-agent", "query", args)
	if err != nil {
		return nil, err
	}

	query, ok := args["query"].(string)
	if !ok || query == "" {
		return nil, fmt.Errorf("query is required")
	}

	decisions, err := s.store.GetDecisionsByScope(context.Background(), tenantID, "", "")
	if err != nil {
		return nil, err
	}

	results := make([]map[string]interface{}, 0)
	for _, d := range decisions {
		if strings.Contains(strings.ToLower(d.Title), strings.ToLower(query)) {
			results = append(results, map[string]interface{}{
				"id":         d.ID.String(),
				"title":      d.Title,
				"status":     d.Status.String(),
				"scope":      d.Scope,
				"confidence": d.Confidence,
			})
		}
	}

	commitBudget()

	return map[string]interface{}{
		"query":   query,
		"count":   len(results),
		"results": results,
	}, nil
}

func (s *MCPServer) handleGetLineage(args map[string]interface{}) (interface{}, error) {
	tenantID, _ := s.resolveTenant(args)
	commitBudget, err := s.checkAndConsumeBudget(context.Background(), tenantID, "mcp-agent", "get_lineage", args)
	if err != nil {
		return nil, err
	}

	decisionIDStr, ok := args["decision_id"].(string)
	if !ok || decisionIDStr == "" {
		return nil, fmt.Errorf("decision_id is required")
	}
	decisionID, err := uuid.Parse(decisionIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid decision_id")
	}

	decision, err := s.store.GetDecision(context.Background(), tenantID, decisionID)
	if err != nil {
		return nil, err
	}

	children, _ := s.store.ListDecisionsByParent(context.Background(), tenantID, decisionID)

	var parent *types.Decision
	if decision.ParentID != nil && *decision.ParentID != uuid.Nil {
		p, _ := s.store.GetDecision(context.Background(), tenantID, *decision.ParentID)
		parent = p
	}

	commitBudget()

	return map[string]interface{}{
		"decision": decision,
		"children": children,
		"parent":   parent,
	}, nil
}

func (s *MCPServer) handleDetectContradictions(args map[string]interface{}) (interface{}, error) {
	tenantID, err := s.resolveTenant(args)
	if err != nil {
		return nil, fmt.Errorf("failed to resolve tenant: %w", err)
	}

	commitBudget, err := s.checkAndConsumeBudget(context.Background(), tenantID, "mcp-agent", "detect_contradictions", args)
	if err != nil {
		return nil, err
	}

	contradictions, err := s.store.ListContradictions(context.Background(), tenantID, false)
	if err != nil {
		commitBudget()
		return nil, fmt.Errorf("failed to query contradictions: %w", err)
	}

	commitBudget()

	return map[string]interface{}{
		"tenant_id":      tenantID.String(),
		"count":          len(contradictions),
		"contradictions": contradictions,
	}, nil
}

func (s *MCPServer) handleGetImpact(args map[string]interface{}) (interface{}, error) {
	tenantID, _ := s.resolveTenant(args)
	commitBudget, err := s.checkAndConsumeBudget(context.Background(), tenantID, "mcp-agent", "get_impact", args)
	if err != nil {
		return nil, err
	}

	decisionIDStr, ok := args["decision_id"].(string)
	if !ok || decisionIDStr == "" {
		return nil, fmt.Errorf("decision_id is required")
	}
	decisionID, err := uuid.Parse(decisionIDStr)
	if err != nil {
		return nil, fmt.Errorf("invalid decision_id")
	}

	children, _ := s.store.ListDecisionsByParent(context.Background(), tenantID, decisionID)

	commitBudget()

	return map[string]interface{}{
		"decision_id":     decisionID.String(),
		"impact_count":    len(children),
		"impact_children": children,
	}, nil
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

func (s *MCPServer) resolveTenant(args map[string]interface{}) (uuid.UUID, error) {
	if tenantStr, ok := args["tenant_id"].(string); ok && tenantStr != "" {
		return uuid.Parse(tenantStr)
	}
	// Fall back to the canonical tenant, matching every other CLI and
	// HTTP path. The previous implementation returned a synthetic
	// UUID derived from the literal "default-tenant"; that UUID matches
	// no row in any table, so tenant-scoped queries produced empty
	// results with no error. Same class of silent miss as the six CLI
	// sites fixed in 13018d1.
	return tenant.CanonicalID, nil
}

func (s *MCPServer) errorResponse(id interface{}, code int, message string) MCPResponse {
	return MCPResponse{
		JSONRPC: "2.0",
		ID:      id,
		Error: &MCPError{
			Code:    code,
			Message: message,
		},
	}
}

func mustJSON(v interface{}) string {
	b, _ := json.MarshalIndent(v, "", "  ")
	return string(b)
}
